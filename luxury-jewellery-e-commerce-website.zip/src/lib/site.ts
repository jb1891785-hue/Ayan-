// Central place for brand settings. Owners can override the WhatsApp number
// and admin password through environment variables (see .env).
export const SITE = {
  name: "IBRI ELAN",
  tagline: "Jewellery That Speaks Elegance ♡",
  currency: "PKR",
  instagramHandle: "@ibri_elan",
  instagramUrl: "https://www.instagram.com/ibri_elan/",
  // Digits only, country code first (no +, no spaces). Editable via env.
  whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "923000000000",
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "",
  city: "Pakistan",
} as const;

export const CATEGORIES = [
  { slug: "necklaces", label: "Necklaces", image: "https://images.pexels.com/photos/6964468/pexels-photo-6964468.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800" },
  { slug: "earrings", label: "Earrings", image: "https://images.pexels.com/photos/39076778/pexels-photo-39076778.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800" },
  { slug: "rings", label: "Rings", image: "https://images.pexels.com/photos/9953656/pexels-photo-9953656.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800" },
  { slug: "bracelets", label: "Bracelets", image: "https://images.pexels.com/photos/35841164/pexels-photo-35841164.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800" },
  { slug: "jewellery-sets", label: "Jewellery Sets", image: "https://images.pexels.com/photos/10944923/pexels-photo-10944923.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800" },
  { slug: "new-arrivals", label: "New Arrivals", image: "https://images.pexels.com/photos/20507408/pexels-photo-20507408.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800" },
  { slug: "best-sellers", label: "Best Sellers", image: "https://images.pexels.com/photos/26898066/pexels-photo-26898066.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800" },
] as const;

export type CategorySlug = (typeof CATEGORIES)[number]["slug"];

// Product rows store the product category as one of these keys (not the URL slug)
export const PRODUCT_CATEGORIES = [
  { value: "necklaces", label: "Necklaces" },
  { value: "earrings", label: "Earrings" },
  { value: "rings", label: "Rings" },
  { value: "bracelets", label: "Bracelets" },
  { value: "jewellery-sets", label: "Jewellery Sets" },
] as const;

export const CATEGORY_LABELS: Record<string, string> = Object.fromEntries(
  [
    { value: "necklaces", label: "Necklaces" },
    { value: "earrings", label: "Earrings" },
    { value: "rings", label: "Rings" },
    { value: "bracelets", label: "Bracelets" },
    { value: "jewellery-sets", label: "Jewellery Sets" },
  ].map((c) => [c.value, c.label]),
);

export const PAYMENT_METHODS = [
  { value: "cod", label: "Cash on Delivery" },
  { value: "bank", label: "Bank Transfer (details sent on confirmation)" },
  { value: "card", label: "Card / Online Payment (secure link sent on confirmation)" },
] as const;

export const SHOP_HOME_PATH = "/shop";
