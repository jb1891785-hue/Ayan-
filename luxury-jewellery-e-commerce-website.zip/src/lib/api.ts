import { PRODUCT_CATEGORIES } from "@/lib/site";

export function getAdminKey() {
  return process.env.ADMIN_PASSWORD || "ibrielan-admin";
}

export function isAdmin(req: Request) {
  const key = req.headers.get("x-admin-key") || "";
  const expected = getAdminKey();
  if (key.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < key.length; i++) diff |= key.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

export function unauthorized() {
  return Response.json({ error: "Unauthorised. Check your admin password." }, { status: 401 });
}

export function badRequest(message: string) {
  return Response.json({ error: message }, { status: 400 });
}

export type ProductInput = {
  name: string;
  category: string;
  price: number;
  compareAtPrice: number | null;
  description: string;
  variations: string[];
  image: string;
  isNewArrival: boolean;
  isBestSeller: boolean;
  isActive: boolean;
};

const MAX_IMAGE_LENGTH = 1_500_000; // ~1.1 MB of base64 data

export function parseProductInput(body: unknown): { value?: ProductInput; error?: string } {
  if (!body || typeof body !== "object") return { error: "Invalid request body." };
  const b = body as Record<string, unknown>;

  const name = String(b.name ?? "").trim();
  if (!name || name.length > 160) return { error: "Product name is required (max 160 characters)." };

  const category = String(b.category ?? "");
  if (!PRODUCT_CATEGORIES.some((c) => c.value === category)) {
    return { error: "Please choose a valid category." };
  }

  const price = Math.round(Number(b.price));
  if (!Number.isFinite(price) || price < 0) return { error: "Price must be a valid PKR amount." };

  let compareAtPrice: number | null = null;
  if (b.compareAtPrice !== null && b.compareAtPrice !== undefined && b.compareAtPrice !== "") {
    compareAtPrice = Math.round(Number(b.compareAtPrice));
    if (!Number.isFinite(compareAtPrice) || compareAtPrice < 0) {
      return { error: "Compare-at price must be a valid PKR amount." };
    }
  }

  const variations = Array.isArray(b.variations)
    ? b.variations.map((v) => String(v).trim()).filter(Boolean).slice(0, 20)
    : String(b.variations ?? "")
        .split(",")
        .map((v) => v.trim())
        .filter(Boolean)
        .slice(0, 20);

  const image = String(b.image ?? "").trim();
  if (image && !/^(https?:\/\/|data:image\/(jpeg|png|webp);base64,)/.test(image)) {
    return { error: "Image must be an https link or an uploaded image." };
  }
  if (image.length > MAX_IMAGE_LENGTH) return { error: "Image is too large. Please use a smaller image." };

  return {
    value: {
      name,
      category,
      price,
      compareAtPrice,
      description: String(b.description ?? "").trim().slice(0, 2000),
      variations,
      image,
      isNewArrival: Boolean(b.isNewArrival),
      isBestSeller: Boolean(b.isBestSeller),
      isActive: b.isActive === undefined ? true : Boolean(b.isActive),
    },
  };
}
