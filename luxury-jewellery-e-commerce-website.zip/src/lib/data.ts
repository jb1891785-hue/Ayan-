import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { and, asc, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";

export type Product = typeof products.$inferSelect;
export type Review = typeof reviews.$inferSelect;

export type ProductFilter = {
  category?: string;
  collection?: "new" | "best";
  q?: string;
  sort?: "newest" | "price-asc" | "price-desc" | "name";
  includeInactive?: boolean;
};

export async function listProducts(filter: ProductFilter = {}): Promise<Product[]> {
  const conditions: SQL[] = filter.includeInactive ? [] : [eq(products.isActive, true)];
  if (filter.category) conditions.push(eq(products.category, filter.category));
  if (filter.collection === "new") conditions.push(eq(products.isNewArrival, true));
  if (filter.collection === "best") conditions.push(eq(products.isBestSeller, true));
  if (filter.q && filter.q.trim()) {
    const term = `%${filter.q.trim().replace(/[%_]/g, "\\$&")}%`;
    conditions.push(or(ilike(products.name, term), ilike(products.description, term))!);
  }

  const order =
    filter.sort === "price-asc"
      ? asc(products.price)
      : filter.sort === "price-desc"
        ? desc(products.price)
        : filter.sort === "name"
          ? asc(products.name)
          : desc(products.createdAt);

  return db
    .select()
    .from(products)
    .where(and(...conditions))
    .orderBy(order, desc(products.id));
}

export async function getProduct(id: number): Promise<Product | null> {
  const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function getProductReviews(productId: number): Promise<Review[]> {
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.createdAt));
}

export async function getReviewSummary(productId: number) {
  const rows = await db
    .select({
      count: sql<number>`count(*)::int`,
      average: sql<number>`coalesce(round(avg(${reviews.rating})::numeric, 1), 0)::float`,
    })
    .from(reviews)
    .where(eq(reviews.productId, productId));
  return rows[0] ?? { count: 0, average: 0 };
}
