export function formatPKR(amount: number) {
  return `PKR ${Math.round(amount).toLocaleString("en-PK")}`;
}
