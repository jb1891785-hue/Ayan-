import { db } from "@/db";
import { reviews } from "@/db/schema";
import { getProductReviews, getReviewSummary } from "@/lib/data";
import { badRequest } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const productId = Number(new URL(req.url).searchParams.get("productId"));
  if (!Number.isInteger(productId) || productId <= 0) return badRequest("productId is required.");
  const [items, summary] = await Promise.all([
    getProductReviews(productId),
    getReviewSummary(productId),
  ]);
  return Response.json({ reviews: items, summary });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return badRequest("Invalid request body.");

  const productId = Number(body.productId);
  const rating = Math.round(Number(body.rating));
  const name = String(body.name ?? "").trim();
  const comment = String(body.comment ?? "").trim();

  if (!Number.isInteger(productId) || productId <= 0) return badRequest("Invalid product.");
  if (!(rating >= 1 && rating <= 5)) return badRequest("Rating must be between 1 and 5.");
  if (!name || name.length > 120) return badRequest("Please enter your name.");
  if (comment.length < 5 || comment.length > 1000) {
    return badRequest("Review must be between 5 and 1000 characters.");
  }

  const [created] = await db
    .insert(reviews)
    .values({ productId, rating, name, comment })
    .returning();
  return Response.json({ review: created }, { status: 201 });
}
