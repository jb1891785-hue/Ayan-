import { db } from "@/db";
import { products } from "@/db/schema";
import { getProduct } from "@/lib/data";
import { badRequest, isAdmin, parseProductInput, unauthorized } from "@/lib/api";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function parseId(raw: string) {
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 ? id : null;
}

export async function GET(_req: Request, ctx: Ctx) {
  const id = parseId((await ctx.params).id);
  if (!id) return badRequest("Invalid product id.");
  const product = await getProduct(id);
  if (!product) return Response.json({ error: "Product not found." }, { status: 404 });
  return Response.json({ product });
}

export async function PUT(req: Request, ctx: Ctx) {
  if (!isAdmin(req)) return unauthorized();
  const id = parseId((await ctx.params).id);
  if (!id) return badRequest("Invalid product id.");

  const body = await req.json().catch(() => null);
  const parsed = parseProductInput(body);
  if (!parsed.value) return badRequest(parsed.error ?? "Invalid product.");

  const [updated] = await db
    .update(products)
    .set({ ...parsed.value, updatedAt: new Date() })
    .where(eq(products.id, id))
    .returning();
  if (!updated) return Response.json({ error: "Product not found." }, { status: 404 });
  return Response.json({ product: updated });
}

export async function DELETE(req: Request, ctx: Ctx) {
  if (!isAdmin(req)) return unauthorized();
  const id = parseId((await ctx.params).id);
  if (!id) return badRequest("Invalid product id.");
  await db.delete(products).where(eq(products.id, id));
  return Response.json({ ok: true });
}
