import { db } from "@/db";
import { products } from "@/db/schema";
import { listProducts, type ProductFilter } from "@/lib/data";
import { badRequest, isAdmin, parseProductInput, unauthorized } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const filter: ProductFilter = {
    category: url.searchParams.get("category") || undefined,
    collection:
      url.searchParams.get("collection") === "new"
        ? "new"
        : url.searchParams.get("collection") === "best"
          ? "best"
          : undefined,
    q: url.searchParams.get("q") || undefined,
    sort: (url.searchParams.get("sort") as ProductFilter["sort"]) || undefined,
    includeInactive: url.searchParams.get("all") === "1" && isAdmin(req),
  };
  const items = await listProducts(filter);
  return Response.json({ products: items });
}

export async function POST(req: Request) {
  if (!isAdmin(req)) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = parseProductInput(body);
  if (!parsed.value) return badRequest(parsed.error ?? "Invalid product.");

  const [created] = await db
    .insert(products)
    .values({ ...parsed.value, updatedAt: new Date() })
    .returning();
  return Response.json({ product: created }, { status: 201 });
}

