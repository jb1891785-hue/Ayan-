import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { badRequest, isAdmin, unauthorized } from "@/lib/api";
import { PAYMENT_METHODS } from "@/lib/site";
import { desc, eq, inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";

type CartLine = { productId: number; variation: string | null; quantity: number };

function makeOrderNumber() {
  const stamp = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `IE-${stamp}-${rand}`;
}

// Creates an order. Prices are always re-read from the database so the
// browser can never change what a customer pays.
export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return badRequest("Invalid request body.");

  const customerName = String(body.customerName ?? "").trim();
  const phone = String(body.phone ?? "").trim();
  const email = String(body.email ?? "").trim();
  const address = String(body.address ?? "").trim();
  const city = String(body.city ?? "").trim();
  const notes = String(body.notes ?? "").trim().slice(0, 1000);
  const paymentMethod = String(body.paymentMethod ?? "");

  if (customerName.length < 2 || customerName.length > 120) return badRequest("Please enter your full name.");
  if (!/^[+0-9 ()-]{7,25}$/.test(phone)) return badRequest("Please enter a valid phone number.");
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return badRequest("Please enter a valid email.");
  if (address.length < 5 || address.length > 500) return badRequest("Please enter your delivery address.");
  if (city.length < 2 || city.length > 80) return badRequest("Please enter your city.");
  if (!PAYMENT_METHODS.some((p) => p.value === paymentMethod)) return badRequest("Choose a payment method.");

  const rawItems = Array.isArray(body.items) ? (body.items as CartLine[]) : [];
  const lines = rawItems
    .map((i) => ({
      productId: Number(i.productId),
      variation: i.variation ? String(i.variation).slice(0, 80) : null,
      quantity: Math.min(Math.max(Math.round(Number(i.quantity)), 1), 20),
    }))
    .filter((i) => Number.isInteger(i.productId) && i.productId > 0 && Number.isFinite(i.quantity));
  if (lines.length === 0) return badRequest("Your cart is empty.");

  const ids = [...new Set(lines.map((l) => l.productId))];
  const rows = await db
    .select()
    .from(products)
    .where(inArray(products.id, ids));
  const byId = new Map(rows.map((r) => [r.id, r]));

  const items = [];
  for (const line of lines) {
    const product = byId.get(line.productId);
    if (!product || !product.isActive) {
      return badRequest("One of the items in your cart is no longer available. Please update your cart.");
    }
    if (line.variation && product.variations.length > 0 && !product.variations.includes(line.variation)) {
      return badRequest(`Invalid variation selected for ${product.name}.`);
    }
    items.push({
      productId: product.id,
      name: product.name,
      variation: line.variation,
      unitPrice: product.price,
      quantity: line.quantity,
    });
  }

  const subtotal = items.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);

  const [created] = await db
    .insert(orders)
    .values({
      orderNumber: makeOrderNumber(),
      customerName,
      phone,
      email,
      address,
      city,
      notes,
      paymentMethod,
      items,
      subtotal,
    })
    .returning();

  return Response.json({ order: { id: created.id, orderNumber: created.orderNumber } }, { status: 201 });
}

// Admin: list all orders
export async function GET(req: Request) {
  if (!isAdmin(req)) return unauthorized();
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(200);
  return Response.json({ orders: rows });
}

// Admin: update order status
export async function PATCH(req: Request) {
  if (!isAdmin(req)) return unauthorized();
  const body = (await req.json().catch(() => null)) as { id?: number; status?: string } | null;
  const allowed = ["pending", "confirmed", "shipped", "delivered", "cancelled"];
  if (!body?.id || !allowed.includes(String(body.status))) return badRequest("Invalid status update.");
  await db.update(orders).set({ status: String(body.status) }).where(eq(orders.id, Number(body.id)));
  return Response.json({ ok: true });
}
