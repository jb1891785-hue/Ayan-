import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import Reveal from "@/components/Reveal";
import { formatPKR } from "@/lib/format";
import { PAYMENT_METHODS, SITE } from "@/lib/site";
import { whatsappLink } from "@/components/WhatsAppFloat";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Order Confirmed" };

type Params = Promise<{ orderNumber: string }>;

export default async function OrderConfirmationPage({ params }: { params: Params }) {
  const { orderNumber } = await params;
  const rows = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  const order = rows[0];
  if (!order) notFound();

  const payment = PAYMENT_METHODS.find((p) => p.value === order.paymentMethod)?.label ?? order.paymentMethod;
  const placed = order.createdAt.toLocaleString("en-GB", { dateStyle: "long", timeStyle: "short" });

  return (
    <>
      <section className="relative overflow-hidden bg-burgundy-deep px-6 pb-16 pt-20 text-center text-ivory sm:px-8 sm:pt-28">
        <div className="grain absolute inset-0 opacity-30" aria-hidden />
        <div className="absolute left-1/2 top-10 h-72 w-72 -translate-x-1/2 rounded-full bg-gold/15 blur-3xl" aria-hidden />
        <Reveal className="relative mx-auto max-w-2xl">
          <span className="mx-auto grid h-20 w-20 place-items-center rounded-full border border-gold bg-gold/10 font-serif text-4xl text-gold-light animate-sparkle">✓</span>
          <p className="eyebrow mt-8 !text-gold-light">Order Confirmed</p>
          <h1 className="mt-3 font-serif text-5xl sm:text-6xl">Thank you, {order.customerName.split(" ")[0]}.</h1>
          <p className="mx-auto mt-5 max-w-lg font-sans text-base leading-relaxed text-ivory/75">
            Your order has been received. Keep your order number handy — our team will contact you on{" "}
            <span className="text-gold-light">{order.phone}</span> to finalise delivery.
          </p>
          <p className="mt-8 inline-block rounded-full border border-gold/50 px-6 py-3 font-sans text-sm tracking-[0.2em] text-gold-light">
            {order.orderNumber}
          </p>
        </Reveal>
      </section>

      <section className="bg-ivory px-6 py-16 sm:px-8 lg:px-10 lg:py-20">
        <div className="mx-auto grid max-w-5xl gap-10 lg:grid-cols-12">
          <Reveal className="rounded-[1.5rem] bg-white p-7 shadow-[0_18px_40px_-30px_rgba(63,7,18,0.4)] ring-1 ring-burgundy/5 sm:p-9 lg:col-span-7">
            <h2 className="font-serif text-3xl text-burgundy-deep">Items Ordered</h2>
            <ul className="mt-6 divide-y divide-burgundy/10">
              {order.items.map((item, i) => (
                <li key={i} className="flex items-start justify-between gap-4 py-4">
                  <div>
                    <p className="font-serif text-xl text-burgundy-deep">{item.name}</p>
                    <p className="mt-1 font-sans text-sm text-burgundy-deep/60">
                      {item.variation ? `${item.variation} · ` : ""}Qty {item.quantity} × {formatPKR(item.unitPrice)}
                    </p>
                  </div>
                  <p className="font-sans text-base font-medium text-burgundy">{formatPKR(item.unitPrice * item.quantity)}</p>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex items-baseline justify-between border-t border-gold/40 pt-6">
              <span className="font-serif text-xl text-burgundy-deep">Total</span>
              <span className="font-sans text-2xl font-medium text-burgundy">{formatPKR(order.subtotal)}</span>
            </div>
          </Reveal>

          <Reveal delay={1} className="space-y-6 rounded-[1.5rem] bg-beige/70 p-7 ring-1 ring-burgundy/5 sm:p-9 lg:col-span-5">
            <div>
              <p className="eyebrow !text-[0.62rem]">Delivering To</p>
              <p className="mt-2 font-sans text-sm leading-relaxed text-burgundy-deep/80">
                {order.customerName}<br />
                {order.address}<br />
                {order.city}
              </p>
            </div>
            <div>
              <p className="eyebrow !text-[0.62rem]">Payment</p>
              <p className="mt-2 font-sans text-sm text-burgundy-deep/80">{payment}</p>
            </div>
            <div>
              <p className="eyebrow !text-[0.62rem]">Placed On</p>
              <p className="mt-2 font-sans text-sm text-burgundy-deep/80">{placed}</p>
            </div>
            <div className="grid gap-3 pt-2">
              <a
                href={whatsappLink(`Hello IBRI ELAN, I just placed order ${order.orderNumber}.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-burgundy w-full"
              >
                Confirm on WhatsApp
              </a>
              <Link href="/shop" className="btn-ghost-burgundy w-full">Continue Shopping</Link>
              <a href={SITE.instagramUrl} target="_blank" rel="noopener noreferrer" className="mt-2 text-center font-sans text-xs uppercase tracking-[0.18em] text-burgundy/70 transition-colors hover:text-gold-deep">
                Follow {SITE.instagramHandle}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
