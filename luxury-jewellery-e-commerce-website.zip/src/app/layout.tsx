import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { StoreProvider } from "@/components/store";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: {
    default: "IBRI ELAN | Jewellery That Speaks Elegance",
    template: "%s | IBRI ELAN",
  },
  description:
    "IBRI ELAN — curated stainless steel jewellery: necklaces, earrings, rings, bracelets and sets. Jewellery that speaks elegance.",
  keywords: ["IBRI ELAN", "stainless steel jewellery", "luxury jewellery Pakistan", "necklaces", "earrings", "rings"],
  openGraph: {
    title: "IBRI ELAN | Jewellery That Speaks Elegance",
    description: "Elegance is always in style.",
    siteName: "IBRI ELAN",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#650F20",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="flex min-h-screen flex-col overflow-x-hidden bg-ivory text-burgundy-deep antialiased">
        <StoreProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <WhatsAppFloat />
        </StoreProvider>
        <span className="hidden" data-brand={SITE.name} />
      </body>
    </html>
  );
}
