import type { Metadata } from "next";
import ProductCard from "@/components/ProductCard";
import ShopControls from "@/components/ShopControls";
import Reveal from "@/components/Reveal";
import { listProducts, type ProductFilter } from "@/lib/data";
import { CATEGORIES, CATEGORY_LABELS } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop",
  description: "Shop IBRI ELAN stainless steel jewellery: necklaces, earrings, rings, bracelets and sets.",
};

type SearchParams = Promise<{ category?: string; collection?: string; q?: string; sort?: string }>;

const VALID_SORTS = ["newest", "price-asc", "price-desc", "name"] as const;

export default async function ShopPage({ searchParams }: { searchParams: SearchParams }) {
  const sp = await searchParams;
  const category = sp.category && CATEGORY_LABELS[sp.category] ? sp.category : undefined;
  const collection = sp.collection === "new" || sp.collection === "best" ? sp.collection : undefined;
  const q = (sp.q ?? "").slice(0, 100);
  const sort = VALID_SORTS.includes(sp.sort as (typeof VALID_SORTS)[number]) ? (sp.sort as string) : "newest";

  const filter: ProductFilter = {
    category,
    collection,
    q: q || undefined,
    sort: sort as ProductFilter["sort"],
  };
  const products = await listProducts(filter);

  const activeKey = collection === "new" ? "new-arrivals" : collection === "best" ? "best-sellers" : category ?? "all";
  const tabs = [
    { key: "all", label: "All", href: "/shop" },
    ...CATEGORIES.map((c) => ({
      key: c.slug,
      label: c.label,
      href:
        c.slug === "new-arrivals"
          ? "/shop?collection=new"
          : c.slug === "best-sellers"
            ? "/shop?collection=best"
            : `/shop?category=${c.slug}`,
    })),
  ];

  const heading =
    collection === "new"
      ? "New Arrivals"
      : collection === "best"
        ? "Best Sellers"
        : category
          ? CATEGORY_LABELS[category]
          : "The Collection";

  const params: Record<string, string> = {};
  if (category) params.category = category;
  if (collection) params.collection = collection;
  if (q) params.q = q;
  if (sort !== "newest") params.sort = sort;

  return (
    <>
      <section className="relative overflow-hidden bg-burgundy-deep px-6 pb-16 pt-20 text-center text-ivory sm:px-8 sm:pt-24 lg:pb-20">
        <div className="grain absolute inset-0 opacity-30" aria-hidden />
        <div className="absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-gold/10 blur-3xl" aria-hidden />
        <div className="relative mx-auto max-w-3xl">
          <p className="eyebrow !text-gold-light animate-fade-up">IBRI ELAN · Shop</p>
          <h1 className="animate-fade-up mt-4 font-serif text-5xl sm:text-6xl">{heading}</h1>
          <div className="ornament mt-6 text-sm animate-fade-up">◆</div>
          <p className="animate-fade-up mt-6 font-sans text-sm text-ivory/70">
            {products.length} {products.length === 1 ? "piece" : "pieces"}
            {q ? ` matching “${q}”` : ""}
          </p>
        </div>
      </section>

      <section className="bg-ivory px-6 py-12 sm:px-8 lg:px-10 lg:py-16">
        <div className="mx-auto max-w-7xl">
          <ShopControls
            tabs={tabs}
            activeKey={activeKey}
            q={q}
            sort={sort}
            basePath="/shop"
            params={params}
          />

          {products.length === 0 ? (
            <Reveal className="mt-16 flex flex-col items-center rounded-[1.5rem] border border-dashed border-gold/60 bg-white/50 px-6 py-20 text-center">
              <span className="font-serif text-5xl text-gold">✦</span>
              <h2 className="mt-5 font-serif text-3xl text-burgundy-deep">
                {q || category || collection ? "No pieces found" : "Coming Soon"}
              </h2>
              <p className="mt-3 max-w-md font-sans text-sm leading-relaxed text-burgundy-deep/65">
                {q || category || collection
                  ? "Try a different search or browse another collection."
                  : "Our collection is being curated. Follow us on Instagram for the first look."}
              </p>
            </Reveal>
          ) : (
            <ul className="mt-12 grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-3 xl:grid-cols-4">
              {products.map((p, i) => (
                <li key={p.id}>
                  <Reveal delay={(i % 3) as 0 | 1 | 2 | 3} className="h-full">
                    <ProductCard
                      index={i}
                      product={{
                        id: p.id,
                        name: p.name,
                        category: p.category,
                        price: p.price,
                        compareAtPrice: p.compareAtPrice,
                        description: p.description,
                        variations: p.variations ?? [],
                        image: p.image,
                        isNewArrival: p.isNewArrival,
                        isBestSeller: p.isBestSeller,
                      }}
                    />
                  </Reveal>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </>
  );
}
