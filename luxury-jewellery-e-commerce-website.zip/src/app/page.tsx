import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";
import { listProducts, type Product } from "@/lib/data";
import { CATEGORIES, SITE } from "@/lib/site";
import { whatsappLink } from "@/components/WhatsAppFloat";

export const dynamic = "force-dynamic";

const HERO_IMAGE =
  "https://images.pexels.com/photos/10944923/pexels-photo-10944923.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=2000";
const ABOUT_IMAGE =
  "https://images.pexels.com/photos/17988453/pexels-photo-17988453.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1300&w=1000";

function toCard(p: Product) {
  return {
    id: p.id,
    name: p.name,
    category: p.category,
    price: p.price,
    compareAtPrice: p.compareAtPrice,
    description: p.description,
    variations: p.variations ?? [],
    image: p.image,
    isNewArrival: p.isNewArrival,
    isBestSeller: p.isBestSeller,
  };
}

export default async function HomePage() {
  const [newArrivals, bestSellers] = await Promise.all([
    listProducts({ collection: "new" }),
    listProducts({ collection: "best" }),
  ]);

  return (
    <>
      {/* HERO */}
      <section className="relative isolate flex min-h-[92vh] items-center overflow-hidden bg-burgundy-deep text-ivory sm:min-h-[100vh]">
        <img
          src={HERO_IMAGE}
          alt="Model wearing gold IBRI ELAN jewellery"
          className="absolute inset-0 -z-20 h-full w-full animate-ken-burns object-cover object-[60%_center]"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-burgundy-deep via-burgundy-deep/80 to-burgundy-deep/25" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-burgundy-deep via-transparent to-burgundy-deep/40" />
        <div className="grain absolute inset-0 -z-10 opacity-30" aria-hidden />

        {/* sparkles */}
        {[
          { top: "18%", left: "52%", d: "0s", s: 14 },
          { top: "62%", left: "46%", d: "1.2s", s: 10 },
          { top: "32%", left: "88%", d: "2.1s", s: 12 },
          { top: "76%", left: "78%", d: "0.6s", s: 16 },
        ].map((sp, i) => (
          <span
            key={i}
            aria-hidden
            className="animate-sparkle absolute text-gold-light"
            style={{ top: sp.top, left: sp.left, animationDelay: sp.d, fontSize: sp.s * 2 }}
          >
            ✦
          </span>
        ))}

        <div className="mx-auto grid w-full max-w-7xl items-center gap-10 px-6 pb-24 pt-32 sm:px-8 lg:grid-cols-12 lg:px-10 lg:pb-32">
          <div className="lg:col-span-7">
            <p className="animate-fade-up eyebrow !text-gold-light">Stainless Steel Jewellery · Est. Collection</p>
            <h1 className="animate-fade-up mt-6 font-serif text-[clamp(3rem,8vw,6.5rem)] font-medium leading-[0.98] tracking-tight">
              Elegance Is <em className="font-normal italic text-gold-light">Always</em>{" "}
              <span className="gold-text">In Style.</span>
            </h1>
            <p className="animate-fade-up-delay mt-7 max-w-xl font-sans text-base leading-relaxed text-ivory/80 sm:text-lg">
              Discover jewellery that makes every moment unforgettable.
            </p>
            <div className="animate-fade-up-delay mt-10 flex flex-col gap-4 sm:flex-row">
              <Link href="/shop" className="btn-gold shimmer">
                Shop Collection
              </Link>
              <a href="#collections" className="btn-outline-gold">
                Explore Our Jewellery
              </a>
            </div>
          </div>

          <div className="hidden lg:col-span-5 lg:block">
            <div className="animate-float-slow relative ml-auto w-[330px]">
              <div className="absolute -inset-5 rounded-[2rem] border border-gold/30" aria-hidden />
              <div className="relative overflow-hidden rounded-[1.75rem] shadow-[0_40px_80px_-30px_rgba(0,0,0,0.7)]">
                <img
                  src="https://images.pexels.com/photos/9953656/pexels-photo-9953656.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800"
                  alt="Close-up of a jewellery ring"
                  className="aspect-[4/5] w-full object-cover"
                />
              </div>
              <div className="glass absolute -bottom-6 -left-10 rounded-2xl px-5 py-4">
                <p className="font-serif text-xl italic text-gold-light">Jewellery That Speaks</p>
                <p className="font-sans text-[0.65rem] uppercase tracking-[0.25em] text-ivory/70">Elegance ♡</p>
              </div>
            </div>
          </div>
        </div>

        <a
          href="#collections"
          aria-label="Scroll to collections"
          className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-3 text-gold-light/80 transition-colors hover:text-gold sm:flex"
        >
          <span className="font-sans text-[0.6rem] uppercase tracking-[0.35em]">Scroll</span>
          <span className="h-12 w-px bg-gradient-to-b from-gold to-transparent" />
        </a>
      </section>

      {/* MARQUEE */}
      <div className="overflow-hidden border-y border-gold/30 bg-gold py-4 text-burgundy-deep">
        <div className="animate-marquee flex w-max gap-12 whitespace-nowrap font-serif text-lg italic">
          {Array.from({ length: 2 }).map((_, k) => (
            <div key={k} className="flex gap-12" aria-hidden={k === 1}>
              {["Jewellery That Speaks Elegance ♡", "New Arrivals", "Necklaces", "Earrings", "Rings", "Bracelets", "Jewellery Sets", "Best Sellers"].map((t) => (
                <span key={t} className="flex items-center gap-12">
                  {t} <span className="not-italic text-burgundy/60">✦</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* COLLECTIONS */}
      <section id="collections" className="scroll-mt-24 bg-ivory px-6 py-24 sm:px-8 lg:px-10 lg:py-32">
        <div className="mx-auto max-w-7xl">
          <Reveal className="text-center">
            <p className="eyebrow">Shop by Category</p>
            <h2 className="mt-4 font-serif text-4xl text-burgundy-deep sm:text-5xl">The Collections</h2>
            <div className="ornament mt-6 text-sm">◆</div>
          </Reveal>

          <ul className="mt-14 grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {CATEGORIES.map((c, i) => (
              <Reveal as="li" key={c.slug} delay={(i % 4) as 0 | 1 | 2 | 3} className={i === 0 ? "col-span-2 lg:col-span-2" : ""}>
                <Link
                  href={
                    c.slug === "new-arrivals"
                      ? "/shop?collection=new"
                      : c.slug === "best-sellers"
                        ? "/shop?collection=best"
                        : `/shop?category=${c.slug}`
                  }
                  className={`group relative block overflow-hidden rounded-[1.25rem] bg-burgundy-deep ${i === 0 ? "aspect-[16/10] lg:aspect-[16/8]" : "aspect-[4/5]"}`}
                >
                  <img
                    src={c.image}
                    alt={c.label}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-burgundy-deep/90 via-burgundy-deep/25 to-transparent transition-opacity duration-700 group-hover:from-burgundy-deep" />
                  <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
                    <p className="font-sans text-[0.6rem] uppercase tracking-[0.3em] text-gold-light/80 transition-all duration-500 group-hover:tracking-[0.36em]">
                      Explore
                    </p>
                    <h3 className="mt-1 font-serif text-2xl text-ivory sm:text-3xl">{c.label}</h3>
                    <span className="mt-2 block h-px w-0 bg-gold transition-all duration-700 group-hover:w-full" />
                  </div>
                </Link>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* NEW ARRIVALS */}
      <ProductShelf
        id="new-arrivals"
        eyebrow="Just Landed"
        title="New Arrivals"
        href="/shop?collection=new"
        products={newArrivals}
        emptyText="New pieces will appear here as soon as they are added."
      />

      {/* FEATURE STRIP */}
      <section className="relative overflow-hidden bg-burgundy px-6 py-20 text-ivory sm:px-8 lg:py-24">
        <div className="grain absolute inset-0 opacity-30" aria-hidden />
        <div className="relative mx-auto grid max-w-7xl gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { t: "Curated Stainless Steel", d: "Every piece is selected for a refined, everyday shine." },
            { t: "Order on WhatsApp", d: "Message us directly to choose your piece and arrange delivery." },
            { t: "Secure Checkout", d: "Clear pricing in PKR and a confirmed order for every purchase." },
            { t: "Made for Moments", d: "From morning coffee to evening celebrations, wear it everywhere." },
          ].map((f, i) => (
            <Reveal key={f.t} delay={(i % 4) as 0 | 1 | 2 | 3} className="group border-t border-gold/40 pt-6 text-center sm:text-left">
              <span className="font-serif text-3xl text-gold transition-transform duration-500 group-hover:-translate-y-1 inline-block">✦</span>
              <h3 className="mt-3 font-serif text-2xl">{f.t}</h3>
              <p className="mt-2 font-sans text-sm leading-relaxed text-ivory/70">{f.d}</p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* BEST SELLERS */}
      <ProductShelf
        id="best-sellers"
        eyebrow="Loved by Our Customers"
        title="Best Sellers"
        href="/shop?collection=best"
        products={bestSellers}
        emptyText="Our most-loved pieces will be featured here."
        alt
      />

      {/* ABOUT */}
      <section id="about" className="scroll-mt-24 bg-beige px-6 py-24 sm:px-8 lg:px-10 lg:py-32">
        <div className="mx-auto grid max-w-7xl items-center gap-14 lg:grid-cols-2 lg:gap-20">
          <Reveal className="relative">
            <div className="absolute -left-4 -top-4 h-full w-full rounded-[2rem] border border-gold/60 sm:-left-8 sm:-top-8" aria-hidden />
            <div className="relative overflow-hidden rounded-[2rem] shadow-[0_40px_80px_-40px_rgba(63,7,18,0.6)]">
              <img src={ABOUT_IMAGE} alt="Woman wearing IBRI ELAN jewellery" loading="lazy" className="aspect-[4/5] w-full object-cover transition-transform duration-[1600ms] hover:scale-105" />
            </div>
            <div className="glass absolute -bottom-6 right-6 rounded-2xl bg-burgundy-deep/90 px-6 py-4 text-ivory">
              <p className="font-serif text-2xl italic text-gold-light">IBRI ELAN</p>
              <p className="font-sans text-[0.6rem] uppercase tracking-[0.25em] text-ivory/70">Stainless Steel Jewellery</p>
            </div>
          </Reveal>

          <Reveal delay={1}>
            <p className="eyebrow">About Us</p>
            <h2 className="mt-4 font-serif text-4xl leading-[1.1] text-burgundy-deep sm:text-5xl lg:text-6xl">
              The Beauty of <em className="italic text-burgundy">Everyday</em> Elegance.
            </h2>
            <div className="mt-6 h-px w-24 bg-gradient-to-r from-gold to-transparent" />
            <p className="mt-8 font-sans text-base leading-[1.85] text-burgundy-deep/80 sm:text-lg">
              At IBRI ELAN, we believe jewellery is more than an accessory. It&apos;s an expression of personality,
              confidence and elegance. Our stainless steel jewellery is curated to add a little sparkle to your
              everyday moments.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link href="/shop" className="btn-burgundy">Shop the Collection</Link>
              <a href={SITE.instagramUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost-burgundy">
                Follow {SITE.instagramHandle}
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* CONTACT & SOCIAL */}
      <section id="contact" className="scroll-mt-24 relative overflow-hidden bg-burgundy-deep px-6 py-24 text-ivory sm:px-8 lg:px-10 lg:py-28">
        <div className="grain absolute inset-0 opacity-30" aria-hidden />
        <div className="absolute -right-40 -top-40 h-[30rem] w-[30rem] rounded-full bg-burgundy/60 blur-3xl" aria-hidden />
        <div className="relative mx-auto max-w-7xl">
          <Reveal className="text-center">
            <p className="eyebrow !text-gold-light">Contact &amp; Social</p>
            <h2 className="mt-4 font-serif text-4xl sm:text-5xl">We&apos;d Love to Hear From You</h2>
            <p className="mx-auto mt-5 max-w-2xl font-sans text-base leading-relaxed text-ivory/70">
              Find a piece you love, ask about a variation, or place your order directly on WhatsApp.
            </p>
          </Reveal>

          <div className="mt-14 grid gap-6 md:grid-cols-3">
            <Reveal>
              <a
                href={SITE.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex h-full flex-col items-center rounded-[1.5rem] border border-gold/25 bg-white/[0.03] p-8 text-center transition-all duration-700 hover:-translate-y-1.5 hover:border-gold/70 hover:bg-white/[0.07]"
              >
                <span className="grid h-14 w-14 place-items-center rounded-full border border-gold/50 text-gold transition-all duration-500 group-hover:rotate-6 group-hover:bg-gold group-hover:text-burgundy-deep">
                  <InstagramIcon />
                </span>
                <h3 className="mt-6 font-serif text-2xl">Instagram</h3>
                <p className="mt-2 font-sans text-sm text-gold-light">{SITE.instagramHandle}</p>
                <p className="mt-4 font-sans text-sm text-ivory/60">New drops, styling and behind the sparkle.</p>
                <span className="btn-outline-gold mt-auto !mt-8">Follow on Instagram</span>
              </a>
            </Reveal>

            <Reveal delay={1}>
              <a
                href={whatsappLink("Hello IBRI ELAN, I would like to place an order.")}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex h-full flex-col items-center rounded-[1.5rem] border border-gold/25 bg-white/[0.03] p-8 text-center transition-all duration-700 hover:-translate-y-1.5 hover:border-gold/70 hover:bg-white/[0.07]"
              >
                <span className="grid h-14 w-14 place-items-center rounded-full border border-gold/50 text-gold transition-all duration-500 group-hover:-rotate-6 group-hover:bg-gold group-hover:text-burgundy-deep">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
                    <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.87 9.87 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91C21.96 6.45 17.5 2 12.04 2Z" />
                  </svg>
                </span>
                <h3 className="mt-6 font-serif text-2xl">WhatsApp Ordering</h3>
                <p className="mt-2 font-sans text-sm text-gold-light">+{SITE.whatsappNumber}</p>
                <p className="mt-4 font-sans text-sm text-ivory/60">Chat with us to order, ask questions or get styling help.</p>
                <span className="btn-gold mt-auto !mt-8">Order on WhatsApp</span>
              </a>
            </Reveal>

            <Reveal delay={2}>
              <Link
                href="/shop"
                className="group flex h-full flex-col items-center rounded-[1.5rem] border border-gold/25 bg-white/[0.03] p-8 text-center transition-all duration-700 hover:-translate-y-1.5 hover:border-gold/70 hover:bg-white/[0.07]"
              >
                <span className="grid h-14 w-14 place-items-center rounded-full border border-gold/50 text-gold transition-all duration-500 group-hover:scale-110 group-hover:bg-gold group-hover:text-burgundy-deep">
                  <span className="font-serif text-2xl">♡</span>
                </span>
                <h3 className="mt-6 font-serif text-2xl">Visit the Shop</h3>
                <p className="mt-2 font-sans text-sm text-gold-light">{SITE.tagline}</p>
                <p className="mt-4 font-sans text-sm text-ivory/60">Browse every piece, save favourites and check out securely.</p>
                <span className="btn-outline-gold mt-auto !mt-8">Browse Shop</span>
              </Link>
            </Reveal>
          </div>
        </div>
      </section>
    </>
  );
}

function ProductShelf({
  id,
  eyebrow,
  title,
  href,
  products,
  emptyText,
  alt = false,
}: {
  id: string;
  eyebrow: string;
  title: string;
  href: string;
  products: Product[];
  emptyText: string;
  alt?: boolean;
}) {
  return (
    <section id={id} className={`scroll-mt-24 px-6 py-24 sm:px-8 lg:px-10 lg:py-28 ${alt ? "bg-beige/60" : "bg-ivory"}`}>
      <div className="mx-auto max-w-7xl">
        <Reveal className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <p className="eyebrow">{eyebrow}</p>
            <h2 className="mt-3 font-serif text-4xl text-burgundy-deep sm:text-5xl">{title}</h2>
          </div>
          <Link href={href} className="link-underline pb-1 font-sans text-[0.75rem] uppercase tracking-[0.22em] text-burgundy transition-colors hover:text-gold-deep">
            View All →
          </Link>
        </Reveal>

        {products.length === 0 ? (
          <EmptyShelf text={emptyText} />
        ) : (
          <ul className="mt-12 grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {products.slice(0, 4).map((p, i) => (
              <li key={p.id}>
                <Reveal delay={(i % 4) as 0 | 1 | 2 | 3} className="h-full">
                  <ProductCard product={toCard(p)} index={i} />
                </Reveal>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}

function EmptyShelf({ text }: { text: string }) {
  return (
    <Reveal className="mt-12 flex flex-col items-center rounded-[1.5rem] border border-dashed border-gold/60 bg-white/50 px-6 py-16 text-center">
      <span className="font-serif text-4xl text-gold">✦</span>
      <p className="mt-4 max-w-md font-serif text-2xl text-burgundy-deep">Coming Soon</p>
      <p className="mt-2 max-w-md font-sans text-sm leading-relaxed text-burgundy-deep/65">{text}</p>
    </Reveal>
  );
}

function InstagramIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}
