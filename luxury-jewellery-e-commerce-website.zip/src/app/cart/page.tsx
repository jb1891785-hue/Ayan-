import type { Metadata } from "next";
import CartView from "@/components/CartView";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = { title: "Your Cart" };

export default function CartPage() {
  return (
    <>
      <section className="bg-burgundy-deep px-6 pb-12 pt-16 text-center text-ivory sm:px-8 sm:pt-20">
        <div className="grain absolute inset-x-0 top-0 h-80 opacity-30" aria-hidden />
        <p className="eyebrow !text-gold-light">Shopping Bag</p>
        <h1 className="mt-3 font-serif text-5xl sm:text-6xl">Your Cart</h1>
        <div className="ornament mt-6 text-sm">◆</div>
      </section>
      <section className="bg-ivory px-6 py-14 sm:px-8 lg:px-10 lg:py-20">
        <Reveal className="mx-auto max-w-7xl">
          <CartView />
        </Reveal>
      </section>
    </>
  );
}
