import type { Metadata } from "next";
import CheckoutForm from "@/components/CheckoutForm";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = { title: "Checkout" };

export default function CheckoutPage() {
  return (
    <>
      <section className="bg-burgundy-deep px-6 pb-12 pt-16 text-center text-ivory sm:px-8 sm:pt-20">
        <p className="eyebrow !text-gold-light">Secure Checkout</p>
        <h1 className="mt-3 font-serif text-5xl sm:text-6xl">Almost Yours</h1>
        <div className="ornament mt-6 text-sm">◆</div>
      </section>
      <section className="bg-ivory px-6 py-14 sm:px-8 lg:px-10 lg:py-20">
        <Reveal className="mx-auto max-w-7xl">
          <CheckoutForm />
        </Reveal>
      </section>
    </>
  );
}
