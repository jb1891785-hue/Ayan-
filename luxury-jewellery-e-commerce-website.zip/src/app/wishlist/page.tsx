import type { Metadata } from "next";
import WishlistView from "@/components/WishlistView";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = { title: "Wishlist" };

export default function WishlistPage() {
  return (
    <>
      <section className="bg-burgundy-deep px-6 pb-12 pt-16 text-center text-ivory sm:px-8 sm:pt-20">
        <p className="eyebrow !text-gold-light">Saved Pieces</p>
        <h1 className="mt-3 font-serif text-5xl sm:text-6xl">Your Wishlist</h1>
        <div className="ornament mt-6 text-sm">◆</div>
      </section>
      <section className="bg-ivory px-6 py-14 sm:px-8 lg:px-10 lg:py-20">
        <Reveal className="mx-auto max-w-7xl">
          <WishlistView />
        </Reveal>
      </section>
    </>
  );
}
