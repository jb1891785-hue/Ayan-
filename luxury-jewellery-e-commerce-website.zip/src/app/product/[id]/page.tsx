import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import ProductCard from "@/components/ProductCard";
import ProductPurchase from "@/components/ProductPurchase";
import ReviewSection from "@/components/ReviewSection";
import Reveal from "@/components/Reveal";
import { getProduct, getProductReviews, getReviewSummary, listProducts } from "@/lib/data";
import { formatPKR } from "@/lib/format";
import { CATEGORY_LABELS, SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

type Params = Promise<{ id: string }>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const id = Number((await params).id);
  if (!Number.isInteger(id)) return { title: "Product" };
  const product = await getProduct(id);
  return product
    ? { title: product.name, description: product.description.slice(0, 160) || `${product.name} by IBRI ELAN` }
    : { title: "Product not found" };
}

export default async function ProductPage({ params }: { params: Params }) {
  const id = Number((await params).id);
  if (!Number.isInteger(id) || id <= 0) notFound();

  const product = await getProduct(id);
  if (!product || !product.isActive) notFound();

  const [reviews, summary, related] = await Promise.all([
    getProductReviews(id),
    getReviewSummary(id),
    listProducts({ category: product.category }),
  ]);
  const suggestions = related.filter((p) => p.id !== product.id).slice(0, 4);

  const hasDiscount = product.compareAtPrice && product.compareAtPrice > product.price;

  return (
    <>
      <nav aria-label="Breadcrumb" className="border-b border-burgundy/10 bg-ivory">
        <ol className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-6 py-4 font-sans text-[0.7rem] uppercase tracking-[0.18em] text-burgundy/60 sm:px-8 lg:px-10">
          <li><Link href="/" className="transition-colors hover:text-gold-deep">Home</Link></li>
          <li aria-hidden>/</li>
          <li><Link href="/shop" className="transition-colors hover:text-gold-deep">Shop</Link></li>
          <li aria-hidden>/</li>
          <li><Link href={`/shop?category=${product.category}`} className="transition-colors hover:text-gold-deep">{CATEGORY_LABELS[product.category] ?? product.category}</Link></li>
          <li aria-hidden>/</li>
          <li className="truncate text-burgundy-deep">{product.name}</li>
        </ol>
      </nav>

      <section className="bg-ivory px-6 pb-20 pt-10 sm:px-8 lg:px-10 lg:pt-16">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-12 lg:gap-16">
          <Reveal className="lg:sticky lg:top-28 lg:col-span-7 lg:self-start">
            <div className="img-zoom-wrap relative overflow-hidden rounded-[1.75rem] bg-beige shadow-[0_40px_80px_-40px_rgba(63,7,18,0.5)]">
              {product.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={product.image} alt={product.name} className="aspect-[4/5] w-full object-cover transition-transform duration-[1600ms] ease-out" />
              ) : (
                <div className="grid aspect-[4/5] w-full place-items-center bg-gradient-to-br from-beige via-ivory to-beige">
                  <span className="font-serif text-3xl italic text-burgundy/40">IBRI ELAN</span>
                </div>
              )}
              <div className="absolute left-5 top-5 flex gap-2">
                {product.isNewArrival && <Pill>New</Pill>}
                {product.isBestSeller && <Pill>Best Seller</Pill>}
              </div>
            </div>
          </Reveal>

          <Reveal delay={1} className="lg:col-span-5">
            <p className="eyebrow">{CATEGORY_LABELS[product.category] ?? product.category}</p>
            <h1 className="mt-4 font-serif text-4xl leading-[1.05] text-burgundy-deep sm:text-5xl">{product.name}</h1>

            {summary.count > 0 && (
              <a href="#reviews" className="mt-4 inline-flex items-center gap-2 font-sans text-sm text-burgundy/70 transition-colors hover:text-gold-deep">
                <span className="text-gold">{"★".repeat(Math.round(summary.average))}</span>
                {summary.average.toFixed(1)} · {summary.count} {summary.count === 1 ? "review" : "reviews"}
              </a>
            )}

            <div className="mt-6 flex items-baseline gap-4">
              <span className="font-sans text-3xl font-medium text-burgundy">{formatPKR(product.price)}</span>
              {hasDiscount && (
                <span className="font-sans text-lg text-burgundy-deep/40 line-through">{formatPKR(product.compareAtPrice!)}</span>
              )}
            </div>
            <p className="mt-2 font-sans text-xs uppercase tracking-[0.18em] text-burgundy-deep/50">All prices in PKR</p>

            <div className="my-8 h-px bg-gradient-to-r from-gold via-gold/40 to-transparent" />

            {product.description ? (
              <p className="whitespace-pre-line font-sans text-base leading-[1.85] text-burgundy-deep/80">{product.description}</p>
            ) : (
              <p className="font-serif text-lg italic text-burgundy/60">A piece curated for everyday elegance.</p>
            )}

            <div className="mt-10">
              <ProductPurchase
                product={{
                  id: product.id,
                  name: product.name,
                  category: product.category,
                  price: product.price,
                  compareAtPrice: product.compareAtPrice,
                  variations: product.variations ?? [],
                  image: product.image,
                }}
              />
            </div>

            <ul className="mt-10 grid gap-3 border-t border-burgundy/10 pt-8 font-sans text-sm text-burgundy-deep/75">
              <li className="flex gap-3"><span className="text-gold">✦</span> Secure checkout with a confirmed order for every purchase</li>
              <li className="flex gap-3"><span className="text-gold">✦</span> Prefer to chat? Order directly on WhatsApp</li>
              <li className="flex gap-3"><span className="text-gold">✦</span> Follow {SITE.instagramHandle} for new arrivals</li>
            </ul>
          </Reveal>
        </div>
      </section>

      <section id="reviews" className="scroll-mt-24 bg-beige/60 px-6 py-20 sm:px-8 lg:px-10 lg:py-24">
        <div className="mx-auto max-w-7xl">
          <Reveal>
            <p className="eyebrow">Customer Reviews</p>
            <h2 className="mt-3 font-serif text-4xl text-burgundy-deep sm:text-5xl">What Our Customers Say</h2>
          </Reveal>
          <Reveal delay={1} className="mt-12">
            <ReviewSection
              productId={product.id}
              average={summary.average}
              count={summary.count}
              reviews={reviews.map((r) => ({
                id: r.id,
                name: r.name,
                rating: r.rating,
                comment: r.comment,
                createdAt: r.createdAt.toISOString(),
              }))}
            />
          </Reveal>
        </div>
      </section>

      {suggestions.length > 0 && (
        <section className="bg-ivory px-6 py-20 sm:px-8 lg:px-10 lg:py-24">
          <div className="mx-auto max-w-7xl">
            <Reveal className="text-center">
              <p className="eyebrow">You May Also Love</p>
              <h2 className="mt-3 font-serif text-4xl text-burgundy-deep">More {CATEGORY_LABELS[product.category] ?? "Pieces"}</h2>
            </Reveal>
            <ul className="mt-12 grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
              {suggestions.map((p, i) => (
                <li key={p.id}>
                  <Reveal delay={(i % 4) as 0 | 1 | 2 | 3} className="h-full">
                    <ProductCard
                      index={i}
                      product={{
                        id: p.id,
                        name: p.name,
                        category: p.category,
                        price: p.price,
                        compareAtPrice: p.compareAtPrice,
                        description: p.description,
                        variations: p.variations ?? [],
                        image: p.image,
                        isNewArrival: p.isNewArrival,
                        isBestSeller: p.isBestSeller,
                      }}
                    />
                  </Reveal>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}
    </>
  );
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-burgundy-deep/85 px-3.5 py-1.5 font-sans text-[0.62rem] uppercase tracking-[0.18em] text-gold-light backdrop-blur">
      {children}
    </span>
  );
}
