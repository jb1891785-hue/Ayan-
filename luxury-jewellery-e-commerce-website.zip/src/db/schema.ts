import { sql } from "drizzle-orm";
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  category: varchar("category", { length: 40 }).notNull(),
  // Price in PKR (whole rupees)
  price: integer("price").notNull(),
  compareAtPrice: integer("compare_at_price"),
  description: text("description").notNull().default(""),
  // Array of variation labels, e.g. ["Gold", "Rose Gold", "Silver"]
  variations: jsonb("variations").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  // Image as an https URL or an uploaded data URL
  image: text("image").notNull().default(""),
  isNewArrival: boolean("is_new_arrival").notNull().default(false),
  isBestSeller: boolean("is_best_seller").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 32 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  email: varchar("email", { length: 160 }).notNull().default(""),
  address: text("address").notNull(),
  city: varchar("city", { length: 80 }).notNull(),
  notes: text("notes").notNull().default(""),
  paymentMethod: varchar("payment_method", { length: 40 }).notNull(),
  items: jsonb("items")
    .$type<
      {
        productId: number;
        name: string;
        variation: string | null;
        unitPrice: number;
        quantity: number;
      }[]
    >()
    .notNull(),
  subtotal: integer("subtotal").notNull(),
  status: varchar("status", { length: 30 }).notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 120 }).notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
