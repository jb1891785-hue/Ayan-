"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { useState, type FormEvent } from "react";
import { useStore } from "@/components/store";
import { formatPKR } from "@/lib/format";
import { PAYMENT_METHODS } from "@/lib/site";

export default function CheckoutForm() {
  const router = useRouter();
  const { ready, cart, cartSubtotal, clearCart } = useStore();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    customerName: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    notes: "",
    paymentMethod: "cod",
  });

  function set<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (cart.length === 0) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: cart.map((c) => ({ productId: c.productId, variation: c.variation, quantity: c.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "We could not place your order. Please try again.");
      clearCart();
      router.push(`/order/${data.order.orderNumber}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setBusy(false);
    }
  }

  if (!ready) {
    return <div className="mx-auto h-96 max-w-4xl animate-pulse rounded-3xl bg-beige/60" aria-hidden />;
  }

  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-6 py-20 text-center">
        <h2 className="font-serif text-4xl text-burgundy-deep">Nothing to check out</h2>
        <p className="mt-4 font-sans text-sm text-burgundy-deep/65">Add a piece to your cart to continue.</p>
        <Link href="/shop" className="btn-burgundy mt-10">Browse the Shop</Link>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-10 lg:grid-cols-12">
      <div className="space-y-10 lg:col-span-7">
        <fieldset className="space-y-6 rounded-[1.5rem] bg-white p-6 shadow-[0_18px_40px_-30px_rgba(63,7,18,0.4)] ring-1 ring-burgundy/5 sm:p-9">
          <legend className="mb-2 font-serif text-3xl text-burgundy-deep">Delivery Details</legend>
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="label-luxe" htmlFor="customerName">Full name *</label>
              <input id="customerName" required minLength={2} value={form.customerName} onChange={(e) => set("customerName", e.target.value)} className="input-luxe" autoComplete="name" />
            </div>
            <div>
              <label className="label-luxe" htmlFor="phone">Phone / WhatsApp *</label>
              <input id="phone" type="tel" required value={form.phone} onChange={(e) => set("phone", e.target.value)} className="input-luxe" placeholder="+92 300 0000000" autoComplete="tel" />
            </div>
            <div>
              <label className="label-luxe" htmlFor="email">Email (optional)</label>
              <input id="email" type="email" value={form.email} onChange={(e) => set("email", e.target.value)} className="input-luxe" autoComplete="email" />
            </div>
            <div className="sm:col-span-2">
              <label className="label-luxe" htmlFor="address">Delivery address *</label>
              <textarea id="address" required rows={3} value={form.address} onChange={(e) => set("address", e.target.value)} className="input-luxe resize-none" autoComplete="street-address" />
            </div>
            <div>
              <label className="label-luxe" htmlFor="city">City *</label>
              <input id="city" required value={form.city} onChange={(e) => set("city", e.target.value)} className="input-luxe" autoComplete="address-level2" />
            </div>
            <div className="sm:col-span-2">
              <label className="label-luxe" htmlFor="notes">Order notes (optional)</label>
              <textarea id="notes" rows={2} value={form.notes} onChange={(e) => set("notes", e.target.value)} className="input-luxe resize-none" placeholder="Gift wrapping, preferred delivery time…" />
            </div>
          </div>
        </fieldset>

        <fieldset className="space-y-4 rounded-[1.5rem] bg-white p-6 shadow-[0_18px_40px_-30px_rgba(63,7,18,0.4)] ring-1 ring-burgundy/5 sm:p-9">
          <legend className="mb-2 font-serif text-3xl text-burgundy-deep">Payment Method</legend>
          {PAYMENT_METHODS.map((p) => (
            <label
              key={p.value}
              className={`flex cursor-pointer items-center gap-4 rounded-2xl border p-4 transition-all duration-400 ${
                form.paymentMethod === p.value ? "border-gold bg-gold/10 shadow-[0_10px_25px_-18px_rgba(176,141,79,0.9)]" : "border-burgundy/15 hover:border-gold/60"
              }`}
            >
              <input type="radio" name="paymentMethod" value={p.value} checked={form.paymentMethod === p.value} onChange={() => set("paymentMethod", p.value)} className="h-4 w-4 accent-[#650F20]" />
              <span className="font-sans text-sm text-burgundy-deep">{p.label}</span>
            </label>
          ))}
          <p className="pt-2 font-sans text-xs leading-relaxed text-burgundy-deep/55">
            Your order is confirmed instantly. Our team will reach out on your phone to finalise payment and delivery.
          </p>
        </fieldset>
      </div>

      <aside className="lg:col-span-5">
        <div className="sticky top-28 rounded-[1.5rem] bg-burgundy-deep p-7 text-ivory shadow-[0_30px_60px_-30px_rgba(63,7,18,0.8)] sm:p-8">
          <h2 className="font-serif text-3xl">Your Order</h2>
          <ul className="mt-6 max-h-72 space-y-4 overflow-y-auto pr-2">
            {cart.map((c) => (
              <li key={c.key} className="flex items-start justify-between gap-4 font-sans text-sm">
                <span className="text-ivory/85">
                  {c.name}
                  {c.variation && <span className="block text-xs text-gold-light/80">{c.variation}</span>}
                  <span className="text-xs text-ivory/50">Qty {c.quantity}</span>
                </span>
                <span className="shrink-0">{formatPKR(c.price * c.quantity)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex items-baseline justify-between border-t border-gold/25 pt-6">
            <span className="font-serif text-xl">Total</span>
            <span className="font-sans text-2xl font-medium text-gold-light">{formatPKR(cartSubtotal)}</span>
          </div>

          {error && (
            <p role="alert" className="mt-6 rounded-xl border border-red-300/30 bg-red-900/30 p-4 font-sans text-sm text-red-100">
              {error}
            </p>
          )}

          <button type="submit" disabled={busy} className="btn-gold shimmer mt-8 w-full">
            {busy ? "Placing order…" : "Place Order"}
          </button>
          <p className="mt-4 text-center font-sans text-[0.7rem] text-ivory/45">
            Prices are verified securely on our server at the time of order.
          </p>
        </div>
      </aside>
    </form>
  );
}
