"use client";

import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { formatPKR } from "@/lib/format";
import { CATEGORY_LABELS, PAYMENT_METHODS, PRODUCT_CATEGORIES, SITE } from "@/lib/site";

type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  compareAtPrice: number | null;
  description: string;
  variations: string[];
  image: string;
  isNewArrival: boolean;
  isBestSeller: boolean;
  isActive: boolean;
  createdAt: string;
};

type Order = {
  id: number;
  orderNumber: string;
  customerName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  notes: string;
  paymentMethod: string;
  items: { productId: number; name: string; variation: string | null; unitPrice: number; quantity: number }[];
  subtotal: number;
  status: string;
  createdAt: string;
};

type FormState = {
  id?: number;
  name: string;
  category: string;
  price: string;
  compareAtPrice: string;
  description: string;
  variations: string;
  image: string;
  isNewArrival: boolean;
  isBestSeller: boolean;
  isActive: boolean;
};

const EMPTY_FORM: FormState = {
  name: "",
  category: "necklaces",
  price: "",
  compareAtPrice: "",
  description: "",
  variations: "",
  image: "",
  isNewArrival: true,
  isBestSeller: false,
  isActive: true,
};

const STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled"];
const KEY_STORAGE = "ibri-elan-admin-key";

// Resize uploaded photos so they stay light for the database and fast on phones.
function resizeImage(file: File, maxSide = 1000): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) return reject(new Error("Image processing not supported."));
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.86));
    };
    img.onerror = () => reject(new Error("Could not read that image."));
    img.src = url;
  });
}

export default function AdminPanel() {
  const [adminKey, setAdminKey] = useState<string | null>(null);
  const [keyInput, setKeyInput] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [tab, setTab] = useState<"products" | "orders">("products");

  useEffect(() => {
    const saved = window.sessionStorage.getItem(KEY_STORAGE);
    if (saved) setAdminKey(saved);
  }, []);

  async function login(e: FormEvent) {
    e.preventDefault();
    setLoginError(null);
    const res = await fetch("/api/orders", { headers: { "x-admin-key": keyInput } });
    if (res.ok) {
      window.sessionStorage.setItem(KEY_STORAGE, keyInput);
      setAdminKey(keyInput);
    } else {
      setLoginError("That password is not correct.");
    }
  }

  function logout() {
    window.sessionStorage.removeItem(KEY_STORAGE);
    setAdminKey(null);
    setKeyInput("");
  }

  if (!adminKey) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center px-6 py-20">
        <form onSubmit={login} className="w-full max-w-md rounded-[1.5rem] bg-burgundy-deep p-8 text-ivory shadow-[0_40px_80px_-30px_rgba(63,7,18,0.8)] sm:p-10">
          <p className="eyebrow !text-gold-light">Owner Access</p>
          <h1 className="mt-3 font-serif text-4xl">Admin Panel</h1>
          <p className="mt-3 font-sans text-sm text-ivory/65">Enter your admin password to manage products, prices and orders.</p>
          <label htmlFor="admin-pass" className="mb-2 mt-8 block font-sans text-[0.7rem] uppercase tracking-[0.18em] text-gold-light">Password</label>
          <input id="admin-pass" type="password" required value={keyInput} onChange={(e) => setKeyInput(e.target.value)} className="w-full rounded-xl border border-gold/30 bg-white/5 px-4 py-3 font-sans text-ivory focus:border-gold focus:outline-none" />
          {loginError && <p role="alert" className="mt-3 font-sans text-sm text-red-200">{loginError}</p>}
          <button type="submit" className="btn-gold mt-6 w-full">Sign In</button>
        </form>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-6 py-12 sm:px-8 lg:px-10">
      <div className="flex flex-col gap-6 border-b border-burgundy/15 pb-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="eyebrow">Owner Dashboard</p>
          <h1 className="mt-2 font-serif text-4xl text-burgundy-deep sm:text-5xl">IBRI ELAN Admin</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="inline-flex rounded-full border border-burgundy/20 bg-white p-1">
            {(["products", "orders"] as const).map((t) => (
              <button key={t} type="button" onClick={() => setTab(t)} className={`rounded-full px-5 py-2 font-sans text-xs uppercase tracking-[0.16em] transition-all duration-400 ${tab === t ? "bg-burgundy text-ivory" : "text-burgundy hover:text-gold-deep"}`}>
                {t}
              </button>
            ))}
          </div>
          <button type="button" onClick={logout} className="font-sans text-xs uppercase tracking-[0.16em] text-burgundy/60 transition-colors hover:text-burgundy">Sign out</button>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-gold/40 bg-gold/10 px-5 py-4 font-sans text-xs leading-relaxed text-burgundy-deep/80">
        <strong className="font-medium">Tip:</strong> Your WhatsApp ordering number is set with the <code>NEXT_PUBLIC_WHATSAPP_NUMBER</code> environment variable (digits only, with country code). Current: <code>{SITE.whatsappNumber}</code>. Admin password is set with <code>ADMIN_PASSWORD</code>.
      </div>

      {tab === "products" ? <ProductsManager adminKey={adminKey} /> : <OrdersManager adminKey={adminKey} />}
    </div>
  );
}

async function api<T>(adminKey: string, path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      "x-admin-key": adminKey,
      ...(init.headers || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data as T;
}

function ProductsManager({ adminKey }: { adminKey: string }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState | null>(null);
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [search, setSearch] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<{ products: Product[] }>(adminKey, "/api/products?all=1");
      setProducts(data.products);
    } catch (err) {
      setMessage({ type: "err", text: err instanceof Error ? err.message : "Could not load products." });
    } finally {
      setLoading(false);
    }
  }, [adminKey]);

  useEffect(() => {
    load();
  }, [load]);

  const flash = (type: "ok" | "err", text: string) => {
    setMessage({ type, text });
    window.setTimeout(() => setMessage(null), 3500);
  };

  function toPayload(f: FormState) {
    return {
      name: f.name,
      category: f.category,
      price: f.price,
      compareAtPrice: f.compareAtPrice,
      description: f.description,
      variations: f.variations,
      image: f.image,
      isNewArrival: f.isNewArrival,
      isBestSeller: f.isBestSeller,
      isActive: f.isActive,
    };
  }

  async function save(f: FormState) {
    try {
      if (f.id) {
        await api(adminKey, `/api/products/${f.id}`, { method: "PUT", body: JSON.stringify(toPayload(f)) });
        flash("ok", "Product updated.");
      } else {
        await api(adminKey, "/api/products", { method: "POST", body: JSON.stringify(toPayload(f)) });
        flash("ok", "Product added to the shop.");
      }
      setForm(null);
      await load();
    } catch (err) {
      flash("err", err instanceof Error ? err.message : "Could not save.");
    }
  }

  async function quickPrice(p: Product, value: string) {
    const price = Number(value);
    if (!Number.isFinite(price) || price < 0 || price === p.price) return;
    try {
      await api(adminKey, `/api/products/${p.id}`, {
        method: "PUT",
        body: JSON.stringify({ ...p, price, compareAtPrice: p.compareAtPrice ?? "" }),
      });
      flash("ok", `Price updated for ${p.name}.`);
      await load();
    } catch (err) {
      flash("err", err instanceof Error ? err.message : "Could not update price.");
    }
  }

  async function toggle(p: Product, field: "isActive" | "isNewArrival" | "isBestSeller") {
    try {
      await api(adminKey, `/api/products/${p.id}`, {
        method: "PUT",
        body: JSON.stringify({ ...p, [field]: !p[field], compareAtPrice: p.compareAtPrice ?? "" }),
      });
      await load();
    } catch (err) {
      flash("err", err instanceof Error ? err.message : "Could not update.");
    }
  }

  async function remove(p: Product) {
    if (!window.confirm(`Delete "${p.name}" permanently? This cannot be undone.`)) return;
    try {
      await api(adminKey, `/api/products/${p.id}`, { method: "DELETE" });
      flash("ok", "Product removed.");
      await load();
    } catch (err) {
      flash("err", err instanceof Error ? err.message : "Could not delete.");
    }
  }

  const filtered = useMemo(
    () => products.filter((p) => p.name.toLowerCase().includes(search.trim().toLowerCase())),
    [products, search],
  );

  return (
    <div className="mt-8">
      {message && (
        <div role="status" className={`mb-6 rounded-xl px-5 py-3 font-sans text-sm ${message.type === "ok" ? "bg-emerald-50 text-emerald-900 ring-1 ring-emerald-200" : "bg-red-50 text-red-900 ring-1 ring-red-200"}`}>
          {message.text}
        </div>
      )}

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter products…" className="input-luxe max-w-sm !rounded-full" aria-label="Filter products" />
        <button type="button" onClick={() => setForm({ ...EMPTY_FORM })} className="btn-burgundy">+ Add New Product</button>
      </div>

      {form && (
        <ProductForm
          key={form.id ?? "new"}
          initial={form}
          onCancel={() => setForm(null)}
          onSave={save}
          onError={(t) => flash("err", t)}
        />
      )}

      {loading ? (
        <div className="h-40 animate-pulse rounded-2xl bg-beige/60" />
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-gold/60 bg-white/60 px-6 py-16 text-center">
          <p className="font-serif text-2xl text-burgundy-deep">No products yet</p>
          <p className="mt-2 font-sans text-sm text-burgundy-deep/60">Click “Add New Product” to publish your first piece.</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl bg-white shadow-[0_18px_40px_-30px_rgba(63,7,18,0.4)] ring-1 ring-burgundy/5">
          <div className="hidden grid-cols-12 gap-4 border-b border-burgundy/10 bg-beige/50 px-6 py-3 font-sans text-[0.65rem] uppercase tracking-[0.16em] text-burgundy/70 md:grid">
            <div className="col-span-5">Product</div>
            <div className="col-span-2">Price (PKR)</div>
            <div className="col-span-2">Flags</div>
            <div className="col-span-3 text-right">Actions</div>
          </div>
          <ul className="divide-y divide-burgundy/10">
            {filtered.map((p) => (
              <li key={p.id} className={`grid grid-cols-1 gap-4 px-4 py-5 transition-colors hover:bg-ivory/70 sm:px-6 md:grid-cols-12 md:items-center ${!p.isActive ? "opacity-60" : ""}`}>
                <div className="col-span-5 flex items-center gap-4">
                  <div className="h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-beige">
                    {p.image && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.image} alt="" className="h-full w-full object-cover" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate font-serif text-lg text-burgundy-deep">{p.name}</p>
                    <p className="font-sans text-xs text-burgundy/60">{CATEGORY_LABELS[p.category] ?? p.category}{!p.isActive ? " · Hidden" : ""}</p>
                  </div>
                </div>
                <div className="col-span-2">
                  <PriceInput price={p.price} onCommit={(v) => quickPrice(p, v)} />
                </div>
                <div className="col-span-2 flex flex-wrap gap-2">
                  <FlagButton on={p.isNewArrival} onClick={() => toggle(p, "isNewArrival")} label="New" />
                  <FlagButton on={p.isBestSeller} onClick={() => toggle(p, "isBestSeller")} label="Best" />
                  <FlagButton on={p.isActive} onClick={() => toggle(p, "isActive")} label="Live" />
                </div>
                <div className="col-span-3 flex justify-start gap-3 md:justify-end">
                  <button type="button" onClick={() => setForm({
                    id: p.id,
                    name: p.name,
                    category: p.category,
                    price: String(p.price),
                    compareAtPrice: p.compareAtPrice ? String(p.compareAtPrice) : "",
                    description: p.description,
                    variations: p.variations.join(", "),
                    image: p.image,
                    isNewArrival: p.isNewArrival,
                    isBestSeller: p.isBestSeller,
                    isActive: p.isActive,
                  })} className="btn-ghost-burgundy !px-4 !py-2 !text-[0.65rem]">Edit</button>
                  <button type="button" onClick={() => remove(p)} className="rounded-full border border-red-300 px-4 py-2 font-sans text-[0.65rem] uppercase tracking-[0.16em] text-red-700 transition-all duration-300 hover:bg-red-700 hover:text-white">Delete</button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function PriceInput({ price, onCommit }: { price: number; onCommit: (v: string) => void }) {
  const [value, setValue] = useState(String(price));
  useEffect(() => setValue(String(price)), [price]);
  return (
    <div className="relative">
      <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 font-sans text-xs text-burgundy/50">PKR</span>
      <input
        type="number"
        min={0}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={() => onCommit(value)}
        onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
        aria-label="Price in PKR"
        className="input-luxe !py-2 !pl-12 !text-sm"
      />
    </div>
  );
}

function FlagButton({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button type="button" onClick={onClick} aria-pressed={on} className={`rounded-full border px-3 py-1 font-sans text-[0.6rem] uppercase tracking-[0.14em] transition-all duration-300 ${on ? "border-burgundy bg-burgundy text-ivory" : "border-burgundy/20 text-burgundy/50 hover:border-gold hover:text-burgundy"}`}>
      {label}
    </button>
  );
}

function ProductForm({
  initial,
  onCancel,
  onSave,
  onError,
}: {
  initial: FormState;
  onCancel: () => void;
  onSave: (f: FormState) => Promise<void>;
  onError: (t: string) => void;
}) {
  const [f, setF] = useState<FormState>(initial);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  function set<K extends keyof FormState>(k: K, v: FormState[K]) {
    setF((prev) => ({ ...prev, [k]: v }));
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) return onError("Please choose an image file.");
    setUploading(true);
    try {
      const dataUrl = await resizeImage(file);
      set("image", dataUrl);
    } catch (err) {
      onError(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    await onSave(f);
    setSaving(false);
  }

  return (
    <form onSubmit={submit} className="mb-8 grid gap-8 rounded-[1.5rem] bg-white p-6 shadow-[0_30px_60px_-30px_rgba(63,7,18,0.5)] ring-1 ring-gold/30 sm:p-9 lg:grid-cols-12">
      <div className="lg:col-span-4">
        <p className="label-luxe">Product Photo</p>
        <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-beige">
          {f.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={f.image} alt="Preview" className="h-full w-full object-cover" />
          ) : (
            <div className="grid h-full place-items-center p-6 text-center font-serif italic text-burgundy/50">No photo yet</div>
          )}
          {uploading && <div className="absolute inset-0 grid place-items-center bg-white/70 font-sans text-sm">Processing…</div>}
        </div>
        <label className="btn-ghost-burgundy mt-4 w-full cursor-pointer">
          Upload Photo
          <input type="file" accept="image/*" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} />
        </label>
        <label className="label-luxe mt-5" htmlFor="img-url">…or paste image link</label>
        <input id="img-url" type="url" value={f.image.startsWith("data:") ? "" : f.image} onChange={(e) => set("image", e.target.value)} placeholder="https://…" className="input-luxe !text-sm" />
        {f.image && (
          <button type="button" onClick={() => set("image", "")} className="mt-3 font-sans text-xs uppercase tracking-[0.16em] text-red-700">Remove photo</button>
        )}
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:col-span-8">
        <div className="sm:col-span-2">
          <label className="label-luxe" htmlFor="p-name">Product name *</label>
          <input id="p-name" required maxLength={160} value={f.name} onChange={(e) => set("name", e.target.value)} className="input-luxe" />
        </div>
        <div>
          <label className="label-luxe" htmlFor="p-cat">Category *</label>
          <select id="p-cat" value={f.category} onChange={(e) => set("category", e.target.value)} className="input-luxe">
            {PRODUCT_CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label-luxe" htmlFor="p-price">Price (PKR) *</label>
            <input id="p-price" type="number" required min={0} value={f.price} onChange={(e) => set("price", e.target.value)} className="input-luxe" />
          </div>
          <div>
            <label className="label-luxe" htmlFor="p-compare">Was (PKR)</label>
            <input id="p-compare" type="number" min={0} value={f.compareAtPrice} onChange={(e) => set("compareAtPrice", e.target.value)} className="input-luxe" placeholder="optional" />
          </div>
        </div>
        <div className="sm:col-span-2">
          <label className="label-luxe" htmlFor="p-desc">Description</label>
          <textarea id="p-desc" rows={4} maxLength={2000} value={f.description} onChange={(e) => set("description", e.target.value)} className="input-luxe resize-none" />
        </div>
        <div className="sm:col-span-2">
          <label className="label-luxe" htmlFor="p-var">Variations (comma separated)</label>
          <input id="p-var" value={f.variations} onChange={(e) => set("variations", e.target.value)} className="input-luxe" placeholder="e.g. Gold, Rose Gold, Silver" />
          <p className="mt-1.5 font-sans text-xs text-burgundy/55">Leave empty if the piece has no variations.</p>
        </div>
        <div className="flex flex-wrap gap-5 sm:col-span-2">
          <Check label="New arrival" checked={f.isNewArrival} onChange={(v) => set("isNewArrival", v)} />
          <Check label="Best seller" checked={f.isBestSeller} onChange={(v) => set("isBestSeller", v)} />
          <Check label="Visible in shop" checked={f.isActive} onChange={(v) => set("isActive", v)} />
        </div>
        <div className="flex flex-col-reverse gap-3 sm:col-span-2 sm:flex-row sm:justify-end">
          <button type="button" onClick={onCancel} className="btn-ghost-burgundy">Cancel</button>
          <button type="submit" disabled={saving || uploading} className="btn-burgundy">{saving ? "Saving…" : f.id ? "Save Changes" : "Publish Product"}</button>
        </div>
      </div>
    </form>
  );
}

function Check({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-3 font-sans text-sm text-burgundy-deep">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-4 w-4 accent-[#650F20]" />
      {label}
    </label>
  );
}

function OrdersManager({ adminKey }: { adminKey: string }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<{ orders: Order[] }>(adminKey, "/api/orders");
      setOrders(data.orders);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load orders.");
    } finally {
      setLoading(false);
    }
  }, [adminKey]);

  useEffect(() => {
    load();
  }, [load]);

  async function setStatus(id: number, status: string) {
    try {
      await api(adminKey, "/api/orders", { method: "PATCH", body: JSON.stringify({ id, status }) });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update status.");
    }
  }

  if (loading) return <div className="mt-8 h-40 animate-pulse rounded-2xl bg-beige/60" />;
  if (error) return <p role="alert" className="mt-8 font-sans text-sm text-red-700">{error}</p>;
  if (orders.length === 0) {
    return (
      <div className="mt-8 rounded-2xl border border-dashed border-gold/60 bg-white/60 px-6 py-16 text-center">
        <p className="font-serif text-2xl text-burgundy-deep">No orders yet</p>
        <p className="mt-2 font-sans text-sm text-burgundy-deep/60">New orders from the checkout will appear here.</p>
      </div>
    );
  }

  return (
    <ul className="mt-8 grid gap-5">
      {orders.map((o) => (
        <li key={o.id} className="rounded-2xl bg-white p-6 shadow-[0_18px_40px_-30px_rgba(63,7,18,0.4)] ring-1 ring-burgundy/5 transition-all duration-500 hover:-translate-y-0.5 sm:p-7">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="font-sans text-xs uppercase tracking-[0.18em] text-gold-deep">{o.orderNumber}</p>
              <p className="mt-1 font-serif text-2xl text-burgundy-deep">{o.customerName}</p>
              <p className="font-sans text-sm text-burgundy-deep/70">{o.phone}{o.email ? ` · ${o.email}` : ""}</p>
              <p className="font-sans text-sm text-burgundy-deep/70">{o.address}, {o.city}</p>
              <p className="mt-1 font-sans text-xs text-burgundy/50">{new Date(o.createdAt).toLocaleString("en-GB")}</p>
            </div>
            <div className="flex flex-col items-start gap-3 sm:items-end">
              <p className="font-sans text-xl font-medium text-burgundy">{formatPKR(o.subtotal)}</p>
              <label className="flex items-center gap-2 font-sans text-xs uppercase tracking-[0.14em] text-burgundy/70">
                Status
                <select value={o.status} onChange={(e) => setStatus(o.id, e.target.value)} className="input-luxe !w-auto !rounded-full !py-2 !text-sm capitalize">
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </label>
            </div>
          </div>
          <ul className="mt-5 divide-y divide-burgundy/10 rounded-xl bg-ivory/70 px-5">
            {o.items.map((i, idx) => (
              <li key={idx} className="flex justify-between gap-4 py-3 font-sans text-sm text-burgundy-deep">
                <span>{i.name}{i.variation ? ` (${i.variation})` : ""} × {i.quantity}</span>
                <span>{formatPKR(i.unitPrice * i.quantity)}</span>
              </li>
            ))}
          </ul>
          <p className="mt-4 font-sans text-xs text-burgundy/60">
            Payment: {PAYMENT_METHODS.find((p) => p.value === o.paymentMethod)?.label ?? o.paymentMethod}
            {o.notes ? ` · Note: ${o.notes}` : ""}
          </p>
        </li>
      ))}
    </ul>
  );
}
