"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { useStore } from "@/components/store";
import { formatPKR } from "@/lib/format";
import { SITE } from "@/lib/site";

type Props = {
  product: {
    id: number;
    name: string;
    category: string;
    price: number;
    compareAtPrice: number | null;
    variations: string[];
    image: string;
  };
};

export default function ProductPurchase({ product }: Props) {
  const router = useRouter();
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const [variation, setVariation] = useState<string>(product.variations[0] ?? "");
  const [qty, setQty] = useState(1);
  const wished = isWishlisted(product.id);
  const needsVariation = product.variations.length > 0 && !variation;

  const base = () => ({
    productId: product.id,
    name: product.name,
    price: product.price,
    image: product.image,
    category: product.category,
    variation: variation || null,
  });

  function addCart() {
    if (needsVariation) return;
    addToCart(base(), qty);
  }

  function buyNow() {
    if (needsVariation) return;
    addToCart(base(), qty);
    router.push("/checkout");
  }

  const waText = `Hello IBRI ELAN, I'd like to order: ${product.name}${
    variation ? ` (${variation})` : ""
  } x${qty} — ${formatPKR(product.price * qty)}. Product link: ${typeof window !== "undefined" ? window.location.href : ""}`;
  const waHref = `https://wa.me/${SITE.whatsappNumber}?text=${encodeURIComponent(waText)}`;

  return (
    <div className="space-y-8">
      {product.variations.length > 0 && (
        <div>
          <p className="label-luxe">Choose Variation</p>
          <div className="flex flex-wrap gap-2.5" role="radiogroup" aria-label="Variation">
            {product.variations.map((v) => (
              <button
                key={v}
                type="button"
                role="radio"
                aria-checked={variation === v}
                onClick={() => setVariation(v)}
                className={`rounded-full border px-5 py-2.5 font-sans text-sm transition-all duration-400 ${
                  variation === v
                    ? "border-burgundy bg-burgundy text-ivory shadow-[0_10px_24px_-12px_rgba(101,15,32,0.8)]"
                    : "border-burgundy/20 bg-white text-burgundy hover:-translate-y-0.5 hover:border-gold"
                }`}
              >
                {v}
              </button>
            ))}
          </div>
        </div>
      )}

      <div>
        <p className="label-luxe">Quantity</p>
        <div className="inline-flex items-center overflow-hidden rounded-full border border-burgundy/20 bg-white">
          <button
            type="button"
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            aria-label="Decrease quantity"
            className="h-12 w-12 text-xl text-burgundy transition-colors hover:bg-beige"
          >
            −
          </button>
          <span className="w-12 text-center font-sans text-base font-medium" aria-live="polite">
            {qty}
          </span>
          <button
            type="button"
            onClick={() => setQty((q) => Math.min(20, q + 1))}
            aria-label="Increase quantity"
            className="h-12 w-12 text-xl text-burgundy transition-colors hover:bg-beige"
          >
            +
          </button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <button type="button" onClick={addCart} disabled={needsVariation} className="btn-burgundy">
          Add to Cart
        </button>
        <button type="button" onClick={buyNow} disabled={needsVariation} className="btn-gold shimmer">
          Buy Now
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={() =>
            toggleWishlist({
              productId: product.id,
              name: product.name,
              price: product.price,
              image: product.image,
              category: product.category,
            })
          }
          aria-pressed={wished}
          className="btn-ghost-burgundy gap-2"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill={wished ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.5" aria-hidden>
            <path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z" strokeLinejoin="round" />
          </svg>
          {wished ? "Saved to Wishlist" : "Add to Wishlist"}
        </button>
        <a href={waHref} target="_blank" rel="noopener noreferrer" className="btn-ghost-burgundy gap-2 !border-[#25D366]/50 !text-[#128C3E] hover:!bg-[#25D366] hover:!text-white">
          Order on WhatsApp
        </a>
      </div>

      {needsVariation && (
        <p className="font-sans text-sm text-burgundy/70">Please select a variation to continue.</p>
      )}
    </div>
  );
}
