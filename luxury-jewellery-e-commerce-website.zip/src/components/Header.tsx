"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { useStore } from "@/components/store";
import { SITE } from "@/lib/site";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  { href: "/#about", label: "About Us" },
  { href: "/#contact", label: "Contact Us" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const { cartCount, wishlist } = useStore();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  function submitSearch(e: FormEvent) {
    e.preventDefault();
    const q = query.trim();
    router.push(q ? `/shop?q=${encodeURIComponent(q)}` : "/shop");
    setSearchOpen(false);
  }

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-burgundy-deep/95 shadow-[0_10px_40px_-15px_rgba(40,4,12,0.6)] backdrop-blur-md"
          : "bg-burgundy"
      }`}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-4 px-5 sm:px-8 lg:px-10">
        <Link href="/" className="group flex flex-col leading-none" aria-label="IBRI ELAN home">
          <span className="gold-text font-serif text-[1.65rem] font-semibold tracking-[0.22em] sm:text-3xl">
            IBRI ELAN
          </span>
          <span className="mt-1 hidden font-sans text-[0.6rem] uppercase tracking-[0.3em] text-gold-light/80 transition-colors group-hover:text-gold sm:block">
            Jewellery That Speaks Elegance ♡
          </span>
        </Link>

        <nav className="hidden items-center gap-9 lg:flex" aria-label="Main">
          {NAV.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="link-underline pb-1 font-sans text-[0.78rem] uppercase tracking-[0.2em] text-ivory/90 transition-colors hover:text-gold"
            >
              {item.label}
            </Link>
          ))}
          <a
            href={SITE.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="link-underline pb-1 font-sans text-[0.78rem] uppercase tracking-[0.2em] text-ivory/90 transition-colors hover:text-gold"
          >
            Instagram
          </a>
        </nav>

        <div className="flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={() => setSearchOpen((s) => !s)}
            aria-label="Search products"
            className="grid h-11 w-11 place-items-center rounded-full text-ivory transition-all duration-300 hover:bg-white/10 hover:text-gold"
          >
            <SearchIcon />
          </button>
          <Link
            href="/wishlist"
            aria-label={`Wishlist, ${wishlist.length} items`}
            className="relative grid h-11 w-11 place-items-center rounded-full text-ivory transition-all duration-300 hover:bg-white/10 hover:text-gold"
          >
            <HeartIcon />
            {wishlist.length > 0 && <Badge>{wishlist.length}</Badge>}
          </Link>
          <Link
            href="/cart"
            aria-label={`Cart, ${cartCount} items`}
            className="relative grid h-11 w-11 place-items-center rounded-full text-ivory transition-all duration-300 hover:bg-white/10 hover:text-gold"
          >
            <BagIcon />
            {cartCount > 0 && <Badge>{cartCount}</Badge>}
          </Link>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            className="grid h-11 w-11 place-items-center rounded-full text-ivory transition-all duration-300 hover:bg-white/10 lg:hidden"
          >
            <span className="relative block h-3.5 w-5">
              <span
                className={`absolute left-0 top-0 h-px w-5 bg-current transition-all duration-500 ${open ? "translate-y-[6.5px] rotate-45" : ""}`}
              />
              <span
                className={`absolute left-0 top-[6.5px] h-px w-5 bg-current transition-all duration-500 ${open ? "opacity-0" : ""}`}
              />
              <span
                className={`absolute left-0 top-[13px] h-px w-5 bg-current transition-all duration-500 ${open ? "-translate-y-[6.5px] -rotate-45" : ""}`}
              />
            </span>
          </button>
        </div>
      </div>

      {/* Search bar */}
      <div
        className={`overflow-hidden border-t border-gold/20 transition-all duration-500 ${
          searchOpen ? "max-h-24 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <form onSubmit={submitSearch} className="mx-auto flex max-w-3xl items-center gap-3 px-5 py-4">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search necklaces, earrings, rings…"
            className="w-full border-b border-gold/40 bg-transparent px-1 py-2 font-sans text-base text-ivory placeholder:text-ivory/40 focus:border-gold focus:outline-none"
            aria-label="Search products"
          />
          <button type="submit" className="btn-gold !px-5 !py-2.5">
            Search
          </button>
        </form>
      </div>

      {/* Mobile drawer */}
      <div
        className={`overflow-hidden bg-burgundy-deep transition-all duration-500 lg:hidden ${
          open ? "max-h-[32rem] border-t border-gold/20" : "max-h-0"
        }`}
      >
        <nav className="flex flex-col px-5 py-4" aria-label="Mobile">
          {NAV.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="border-b border-gold/10 py-4 font-serif text-2xl text-ivory transition-colors hover:text-gold"
            >
              {item.label}
            </Link>
          ))}
          <a
            href={SITE.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="py-4 font-serif text-2xl text-ivory transition-colors hover:text-gold"
          >
            Instagram <span className="font-sans text-sm text-gold">{SITE.instagramHandle}</span>
          </a>
        </nav>
      </div>
    </header>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-gold px-1 font-sans text-[0.65rem] font-semibold text-burgundy-deep">
      {children}
    </span>
  );
}

function SearchIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" strokeLinecap="round" />
    </svg>
  );
}

function HeartIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden>
      <path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z" strokeLinejoin="round" />
    </svg>
  );
}

function BagIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden>
      <path d="M5 8h14l-1 12H6L5 8Z" strokeLinejoin="round" />
      <path d="M9 8V6a3 3 0 0 1 6 0v2" strokeLinecap="round" />
    </svg>
  );
}
