"use client";

import Link from "next/link";
import { useStore } from "@/components/store";
import { formatPKR } from "@/lib/format";
import { CATEGORY_LABELS, SITE } from "@/lib/site";
import { whatsappLink } from "@/components/WhatsAppFloat";

export default function CartView() {
  const { ready, cart, cartSubtotal, cartCount, setQuantity, removeFromCart, clearCart } = useStore();

  if (!ready) {
    return <div className="mx-auto h-64 max-w-3xl animate-pulse rounded-3xl bg-beige/60" aria-hidden />;
  }

  if (cart.length === 0) {
    return (
      <div className="mx-auto flex max-w-xl flex-col items-center px-6 py-20 text-center">
        <span className="font-serif text-6xl text-gold">♡</span>
        <h2 className="mt-6 font-serif text-4xl text-burgundy-deep">Your cart is empty</h2>
        <p className="mt-4 font-sans text-sm leading-relaxed text-burgundy-deep/65">
          Discover pieces that speak to you and add them here.
        </p>
        <Link href="/shop" className="btn-burgundy mt-10">Continue Shopping</Link>
      </div>
    );
  }

  const waLines = cart
    .map((c) => `• ${c.name}${c.variation ? ` (${c.variation})` : ""} x${c.quantity} — ${formatPKR(c.price * c.quantity)}`)
    .join("\n");
  const waHref = whatsappLink(`Hello IBRI ELAN, I'd like to place an order:\n${waLines}\nTotal: ${formatPKR(cartSubtotal)}`);

  return (
    <div className="grid gap-10 lg:grid-cols-12">
      <ul className="space-y-5 lg:col-span-8">
        {cart.map((item, i) => (
          <li
            key={item.key}
            className="animate-fade-up flex gap-5 rounded-[1.25rem] bg-white p-4 shadow-[0_18px_40px_-30px_rgba(63,7,18,0.5)] ring-1 ring-burgundy/5 transition-all duration-500 hover:shadow-[0_24px_50px_-28px_rgba(63,7,18,0.55)] sm:gap-6 sm:p-5"
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <Link href={`/product/${item.productId}`} className="relative h-28 w-24 shrink-0 overflow-hidden rounded-xl bg-beige sm:h-36 sm:w-28">
              {item.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={item.image} alt={item.name} className="h-full w-full object-cover transition-transform duration-[1200ms] hover:scale-110" />
              ) : (
                <span className="grid h-full w-full place-items-center font-serif text-sm italic text-burgundy/40">IBRI ELAN</span>
              )}
            </Link>

            <div className="flex min-w-0 flex-1 flex-col">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <p className="eyebrow !text-[0.6rem]">{CATEGORY_LABELS[item.category] ?? item.category}</p>
                  <Link href={`/product/${item.productId}`} className="mt-1 block truncate font-serif text-xl text-burgundy-deep transition-colors hover:text-burgundy sm:text-2xl">
                    {item.name}
                  </Link>
                  {item.variation && (
                    <p className="mt-1 font-sans text-sm text-burgundy-deep/60">Variation: {item.variation}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => removeFromCart(item.key)}
                  className="shrink-0 font-sans text-xs uppercase tracking-[0.16em] text-burgundy/50 transition-colors hover:text-red-700"
                >
                  Remove
                </button>
              </div>

              <div className="mt-auto flex flex-wrap items-end justify-between gap-3 pt-4">
                <div className="inline-flex items-center overflow-hidden rounded-full border border-burgundy/20">
                  <button type="button" aria-label="Decrease quantity" onClick={() => setQuantity(item.key, item.quantity - 1)} className="h-10 w-10 text-lg text-burgundy transition-colors hover:bg-beige">−</button>
                  <span className="w-10 text-center font-sans text-sm font-medium">{item.quantity}</span>
                  <button type="button" aria-label="Increase quantity" onClick={() => setQuantity(item.key, item.quantity + 1)} className="h-10 w-10 text-lg text-burgundy transition-colors hover:bg-beige">+</button>
                </div>
                <p className="font-sans text-base font-medium text-burgundy">{formatPKR(item.price * item.quantity)}</p>
              </div>
            </div>
          </li>
        ))}
      </ul>

      <aside className="lg:col-span-4">
        <div className="sticky top-28 rounded-[1.5rem] bg-burgundy-deep p-7 text-ivory shadow-[0_30px_60px_-30px_rgba(63,7,18,0.8)] sm:p-8">
          <h2 className="font-serif text-3xl">Order Summary</h2>
          <div className="my-6 h-px bg-gradient-to-r from-gold to-transparent" />
          <dl className="space-y-3 font-sans text-sm">
            <div className="flex justify-between text-ivory/75"><dt>Items</dt><dd>{cartCount}</dd></div>
            <div className="flex justify-between text-ivory/75"><dt>Subtotal</dt><dd>{formatPKR(cartSubtotal)}</dd></div>
            <div className="flex justify-between text-ivory/75"><dt>Delivery</dt><dd>Confirmed at checkout</dd></div>
          </dl>
          <div className="mt-6 flex items-baseline justify-between border-t border-gold/25 pt-6">
            <span className="font-serif text-xl">Total</span>
            <span className="font-sans text-2xl font-medium text-gold-light">{formatPKR(cartSubtotal)}</span>
          </div>

          <div className="mt-8 grid gap-3">
            <Link href="/checkout" className="btn-gold shimmer w-full">Proceed to Checkout</Link>
            <a href={waHref} target="_blank" rel="noopener noreferrer" className="btn-outline-gold w-full">Order via WhatsApp</a>
            <Link href="/shop" className="mt-2 text-center font-sans text-xs uppercase tracking-[0.18em] text-ivory/60 transition-colors hover:text-gold">Continue Shopping</Link>
          </div>
          <p className="mt-6 text-center font-sans text-[0.7rem] text-ivory/45">Questions? WhatsApp us or message {SITE.instagramHandle}</p>
          <button type="button" onClick={clearCart} className="mt-4 w-full text-center font-sans text-[0.65rem] uppercase tracking-[0.2em] text-ivory/35 transition-colors hover:text-red-200">Clear cart</button>
        </div>
      </aside>
    </div>
  );
}
