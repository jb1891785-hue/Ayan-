import Link from "next/link";
import { SITE } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-burgundy-deep text-ivory">
      <div className="grain pointer-events-none absolute inset-0 opacity-40" aria-hidden />
      <div className="relative mx-auto max-w-7xl px-6 pb-10 pt-20 sm:px-8 lg:px-10">
        <div className="flex flex-col items-center text-center">
          <span className="gold-text font-serif text-4xl font-semibold tracking-[0.25em] sm:text-5xl">
            IBRI ELAN
          </span>
          <p className="mt-4 font-serif text-xl italic text-gold-light/90">{SITE.tagline}</p>
          <div className="ornament mt-8 w-full max-w-md">
            <span className="text-sm">◆</span>
          </div>
        </div>

        <nav
          aria-label="Footer"
          className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-4 font-sans text-[0.75rem] uppercase tracking-[0.24em]"
        >
          <Link href="/" className="link-underline pb-1 text-ivory/80 transition-colors hover:text-gold">Home</Link>
          <span className="text-gold/40" aria-hidden>|</span>
          <Link href="/shop" className="link-underline pb-1 text-ivory/80 transition-colors hover:text-gold">Shop</Link>
          <span className="text-gold/40" aria-hidden>|</span>
          <Link href="/#about" className="link-underline pb-1 text-ivory/80 transition-colors hover:text-gold">About Us</Link>
          <span className="text-gold/40" aria-hidden>|</span>
          <Link href="/#contact" className="link-underline pb-1 text-ivory/80 transition-colors hover:text-gold">Contact Us</Link>
          <span className="text-gold/40" aria-hidden>|</span>
          <a
            href={SITE.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="link-underline pb-1 text-ivory/80 transition-colors hover:text-gold"
          >
            Instagram
          </a>
        </nav>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-gold/15 pt-8 text-center font-sans text-xs tracking-wide text-ivory/50 sm:flex-row sm:text-left">
          <p>© {new Date().getFullYear()} IBRI ELAN. All rights reserved.</p>
          <p>
            Stainless steel jewellery · Crafted for everyday elegance ·{" "}
            <a href={SITE.instagramUrl} target="_blank" rel="noopener noreferrer" className="text-gold/80 transition-colors hover:text-gold">
              {SITE.instagramHandle}
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
