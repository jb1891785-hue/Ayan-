"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

type Tab = { key: string; label: string; href: string };

export default function ShopControls({
  tabs,
  activeKey,
  q,
  sort,
  basePath,
  params,
}: {
  tabs: Tab[];
  activeKey: string;
  q: string;
  sort: string;
  basePath: string;
  params: Record<string, string>;
}) {
  const router = useRouter();
  const [term, setTerm] = useState(q);

  function build(overrides: Record<string, string | undefined>) {
    const merged = { ...params, ...overrides };
    const sp = new URLSearchParams();
    Object.entries(merged).forEach(([k, v]) => {
      if (v) sp.set(k, v);
    });
    const qs = sp.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  }

  function onSearch(e: FormEvent) {
    e.preventDefault();
    router.push(build({ q: term.trim() || undefined }));
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <form onSubmit={onSearch} className="relative w-full md:max-w-md">
          <svg className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-burgundy/50" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
            <circle cx="11" cy="11" r="7" />
            <path d="m20 20-3.5-3.5" strokeLinecap="round" />
          </svg>
          <input
            type="search"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Search by name or description"
            aria-label="Search products"
            className="input-luxe !rounded-full !py-3.5 pl-11"
          />
        </form>

        <label className="flex items-center gap-3 font-sans text-[0.7rem] uppercase tracking-[0.2em] text-burgundy/80">
          Sort
          <select
            value={sort}
            onChange={(e) => router.push(build({ sort: e.target.value === "newest" ? undefined : e.target.value }))}
            className="input-luxe !w-auto !rounded-full !py-2.5 !text-sm"
          >
            <option value="newest">Newest</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="name">Name A–Z</option>
          </select>
        </label>
      </div>

      <div className="-mx-6 flex gap-2.5 overflow-x-auto px-6 pb-2 [scrollbar-width:none] sm:mx-0 sm:flex-wrap sm:px-0 [&::-webkit-scrollbar]:hidden">
        {tabs.map((t) => {
          const active = t.key === activeKey;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => router.push(t.href)}
              aria-pressed={active}
              className={`shrink-0 rounded-full border px-5 py-2.5 font-sans text-[0.72rem] uppercase tracking-[0.18em] transition-all duration-500 ${
                active
                  ? "border-burgundy bg-burgundy text-ivory shadow-[0_10px_25px_-12px_rgba(101,15,32,0.7)]"
                  : "border-burgundy/20 bg-white/60 text-burgundy hover:-translate-y-0.5 hover:border-gold hover:text-burgundy-deep"
              }`}
            >
              {t.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
