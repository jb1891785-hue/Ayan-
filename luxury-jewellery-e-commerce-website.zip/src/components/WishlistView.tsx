"use client";

import Link from "next/link";
import { useStore } from "@/components/store";
import { formatPKR } from "@/lib/format";
import { CATEGORY_LABELS } from "@/lib/site";

export default function WishlistView() {
  const { ready, wishlist, removeFromWishlist, addToCart } = useStore();

  if (!ready) {
    return <div className="mx-auto h-64 max-w-5xl animate-pulse rounded-3xl bg-beige/60" aria-hidden />;
  }

  if (wishlist.length === 0) {
    return (
      <div className="mx-auto flex max-w-xl flex-col items-center px-6 py-20 text-center">
        <span className="font-serif text-6xl text-gold">♡</span>
        <h2 className="mt-6 font-serif text-4xl text-burgundy-deep">Your wishlist is empty</h2>
        <p className="mt-4 font-sans text-sm leading-relaxed text-burgundy-deep/65">
          Tap the heart on any piece you love and it will be saved here.
        </p>
        <Link href="/shop" className="btn-burgundy mt-10">Explore the Shop</Link>
      </div>
    );
  }

  return (
    <ul className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
      {wishlist.map((w, i) => (
        <li
          key={w.productId}
          className="card-luxe animate-fade-up group flex flex-col"
          style={{ animationDelay: `${i * 70}ms` }}
        >
          <Link href={`/product/${w.productId}`} className="img-zoom-wrap relative block aspect-[4/5] overflow-hidden bg-beige">
            {w.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={w.image} alt={w.name} className="img-zoom" />
            ) : (
              <span className="grid h-full w-full place-items-center font-serif italic text-burgundy/40">IBRI ELAN</span>
            )}
          </Link>
          <div className="flex flex-1 flex-col p-5">
            <p className="eyebrow !text-[0.6rem]">{CATEGORY_LABELS[w.category] ?? w.category}</p>
            <Link href={`/product/${w.productId}`} className="mt-2 line-clamp-2 font-serif text-xl text-burgundy-deep transition-colors hover:text-burgundy">
              {w.name}
            </Link>
            <p className="mt-2 font-sans text-base font-medium text-burgundy">{formatPKR(w.price)}</p>
            <div className="mt-auto grid gap-2 pt-5">
              <Link href={`/product/${w.productId}`} className="btn-burgundy !px-3 !py-3 !text-[0.66rem]">
                Choose Options
              </Link>
              <button
                type="button"
                onClick={() => {
                  addToCart({ productId: w.productId, name: w.name, price: w.price, image: w.image, category: w.category, variation: null });
                }}
                className="btn-ghost-burgundy !px-3 !py-2.5 !text-[0.66rem]"
              >
                Quick Add
              </button>
              <button
                type="button"
                onClick={() => removeFromWishlist(w.productId)}
                className="pt-1 font-sans text-[0.65rem] uppercase tracking-[0.18em] text-burgundy/50 transition-colors hover:text-red-700"
              >
                Remove
              </button>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
