"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store";
import { formatPKR } from "@/lib/format";
import { CATEGORY_LABELS } from "@/lib/site";
import { useState } from "react";

export type ProductCardData = {
  id: number;
  name: string;
  category: string;
  price: number;
  compareAtPrice: number | null;
  description: string;
  variations: string[];
  image: string;
  isNewArrival: boolean;
  isBestSeller: boolean;
};

export default function ProductCard({ product, index = 0 }: { product: ProductCardData; index?: number }) {
  const router = useRouter();
  const { addToCart, toggleWishlist, isWishlisted } = useStore();
  const [variation, setVariation] = useState<string>(product.variations[0] ?? "");
  const [adding, setAdding] = useState(false);
  const wished = isWishlisted(product.id);

  const needsVariation = product.variations.length > 0 && !variation;

  const cartItem = () => ({
    productId: product.id,
    name: product.name,
    price: product.price,
    image: product.image,
    category: product.category,
    variation: variation || null,
  });

  function handleAdd() {
    if (needsVariation) return;
    addToCart(cartItem());
  }

  function handleBuyNow() {
    if (needsVariation) return;
    addToCart(cartItem());
    setAdding(true);
    router.push("/checkout");
  }

  const discount =
    product.compareAtPrice && product.compareAtPrice > product.price
      ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
      : 0;

  return (
    <article
      className="card-luxe group flex flex-col"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <div className="img-zoom-wrap relative aspect-[4/5] overflow-hidden bg-beige">
        <Link href={`/product/${product.id}`} className="block h-full w-full" aria-label={`View ${product.name}`}>
          {product.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={product.image} alt={product.name} loading="lazy" className="img-zoom" />
          ) : (
            <div className="grid h-full w-full place-items-center bg-gradient-to-br from-beige via-ivory to-beige">
              <span className="font-serif text-2xl italic text-burgundy/40">IBRI ELAN</span>
            </div>
          )}
        </Link>

        <div className="pointer-events-none absolute left-4 top-4 flex flex-col items-start gap-2">
          {product.isNewArrival && <Tag>New</Tag>}
          {product.isBestSeller && <Tag>Best Seller</Tag>}
          {discount > 0 && <Tag>−{discount}%</Tag>}
        </div>

        <button
          type="button"
          onClick={() => toggleWishlist({
            productId: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            category: product.category,
          })}
          aria-pressed={wished}
          aria-label={wished ? "Remove from wishlist" : "Add to wishlist"}
          className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full bg-white/90 text-burgundy shadow-md backdrop-blur transition-all duration-300 hover:scale-110 hover:text-gold-deep"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill={wished ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.5" aria-hidden>
            <path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <p className="eyebrow !text-[0.62rem]">{CATEGORY_LABELS[product.category] ?? product.category}</p>
        <h3 className="mt-2 line-clamp-2 font-serif text-[1.45rem] leading-tight text-burgundy-deep">
          <Link href={`/product/${product.id}`} className="transition-colors hover:text-burgundy">
            {product.name}
          </Link>
        </h3>

        <div className="mt-2 flex items-baseline gap-3">
          <span className="font-sans text-lg font-medium text-burgundy">{formatPKR(product.price)}</span>
          {product.compareAtPrice && product.compareAtPrice > product.price && (
            <span className="font-sans text-sm text-burgundy-deep/40 line-through">
              {formatPKR(product.compareAtPrice)}
            </span>
          )}
        </div>

        {product.description && (
          <p className="mt-3 line-clamp-2 font-sans text-sm leading-relaxed text-burgundy-deep/70">
            {product.description}
          </p>
        )}

        {product.variations.length > 0 && (
          <div className="mt-4">
            <p className="mb-2 font-sans text-[0.65rem] uppercase tracking-[0.2em] text-burgundy-deep/60">
              Variation
            </p>
            <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Variation">
              {product.variations.map((v) => (
                <button
                  key={v}
                  type="button"
                  role="radio"
                  aria-checked={variation === v}
                  onClick={() => setVariation(v)}
                  className={`rounded-full border px-3 py-1.5 font-sans text-xs transition-all duration-300 ${
                    variation === v
                      ? "border-burgundy bg-burgundy text-ivory"
                      : "border-burgundy/20 text-burgundy hover:border-gold hover:text-burgundy-deep"
                  }`}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-auto grid grid-cols-2 gap-2.5 pt-6">
          <button
            type="button"
            onClick={handleAdd}
            disabled={needsVariation}
            className="btn-burgundy !px-3 !py-3 !text-[0.68rem] !tracking-[0.14em]"
          >
            Add to Cart
          </button>
          <button
            type="button"
            onClick={handleBuyNow}
            disabled={needsVariation || adding}
            className="btn-gold shimmer !px-3 !py-3 !text-[0.68rem] !tracking-[0.14em]"
          >
            Buy Now
          </button>
        </div>
      </div>
    </article>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-burgundy-deep/85 px-3 py-1 font-sans text-[0.6rem] uppercase tracking-[0.18em] text-gold-light backdrop-blur">
      {children}
    </span>
  );
}
