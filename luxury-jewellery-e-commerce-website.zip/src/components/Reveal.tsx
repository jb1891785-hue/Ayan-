"use client";

import { useEffect, useRef, type ReactNode } from "react";

// Fades and lifts children into view the first time they scroll into the viewport.
export default function Reveal({
  children,
  delay = 0,
  className = "",
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: 0 | 1 | 2 | 3;
  className?: string;
  as?: "div" | "section" | "li" | "article";
}) {
  const ref = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (!("IntersectionObserver" in window)) {
      el.classList.add("is-visible");
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const delayClass = delay ? `reveal-delay-${delay}` : "";
  const classes = `reveal ${delayClass} ${className}`;

  if (Tag === "section") {
    return (
      <section ref={ref as React.RefObject<HTMLElement>} className={classes}>
        {children}
      </section>
    );
  }
  if (Tag === "li") {
    return (
      <li ref={ref as React.RefObject<HTMLLIElement>} className={classes}>
        {children}
      </li>
    );
  }
  if (Tag === "article") {
    return (
      <article ref={ref as React.RefObject<HTMLElement>} className={classes}>
        {children}
      </article>
    );
  }
  return (
    <div ref={ref as React.RefObject<HTMLDivElement>} className={classes}>
      {children}
    </div>
  );
}
