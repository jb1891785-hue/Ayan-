"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export type ReviewItem = {
  id: number;
  name: string;
  rating: number;
  comment: string;
  createdAt: string;
};

export default function ReviewSection({
  productId,
  reviews,
  average,
  count,
}: {
  productId: number;
  reviews: ReviewItem[];
  average: number;
  count: number;
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [status, setStatus] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setStatus(null);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, name, rating, comment }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not submit your review.");
      setName("");
      setComment("");
      setRating(5);
      setStatus({ type: "ok", text: "Thank you! Your review has been published." });
      router.refresh();
    } catch (err) {
      setStatus({ type: "err", text: err instanceof Error ? err.message : "Something went wrong." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-12 lg:grid-cols-12">
      <div className="lg:col-span-7">
        <div className="flex items-center gap-4">
          <span className="font-serif text-5xl text-burgundy-deep">{count ? average.toFixed(1) : "—"}</span>
          <div>
            <Stars value={Math.round(average)} />
            <p className="mt-1 font-sans text-xs uppercase tracking-[0.18em] text-burgundy/60">
              {count} {count === 1 ? "review" : "reviews"}
            </p>
          </div>
        </div>

        {reviews.length === 0 ? (
          <p className="mt-8 rounded-2xl border border-dashed border-gold/60 bg-white/60 p-8 text-center font-serif text-xl italic text-burgundy/70">
            No reviews yet. Be the first to share your thoughts.
          </p>
        ) : (
          <ul className="mt-8 space-y-5">
            {reviews.map((r) => (
              <li key={r.id} className="rounded-2xl bg-white p-6 shadow-[0_18px_40px_-30px_rgba(63,7,18,0.5)] ring-1 ring-burgundy/5 transition-all duration-500 hover:-translate-y-0.5">
                <div className="flex items-center justify-between gap-4">
                  <p className="font-serif text-xl text-burgundy-deep">{r.name}</p>
                  <Stars value={r.rating} small />
                </div>
                <p className="mt-3 font-sans text-sm leading-relaxed text-burgundy-deep/75">{r.comment}</p>
                <p className="mt-3 font-sans text-[0.65rem] uppercase tracking-[0.18em] text-burgundy/40">
                  {new Date(r.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
                </p>
              </li>
            ))}
          </ul>
        )}
      </div>

      <form onSubmit={submit} className="lg:col-span-5">
        <div className="sticky top-28 rounded-[1.5rem] bg-burgundy-deep p-7 text-ivory shadow-[0_30px_60px_-30px_rgba(63,7,18,0.8)] sm:p-9">
          <h3 className="font-serif text-3xl">Write a Review</h3>
          <p className="mt-2 font-sans text-sm text-ivory/60">Share how this piece makes you feel.</p>

          <div className="mt-6 space-y-5">
            <div>
              <span className="mb-2 block font-sans text-[0.7rem] uppercase tracking-[0.18em] text-gold-light">Rating</span>
              <div className="flex gap-1" role="radiogroup" aria-label="Rating">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    role="radio"
                    aria-checked={rating === n}
                    aria-label={`${n} star${n > 1 ? "s" : ""}`}
                    onClick={() => setRating(n)}
                    className={`text-2xl transition-all duration-300 hover:scale-125 ${n <= rating ? "text-gold" : "text-ivory/25"}`}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label htmlFor="rv-name" className="mb-2 block font-sans text-[0.7rem] uppercase tracking-[0.18em] text-gold-light">Your name</label>
              <input id="rv-name" required maxLength={120} value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-xl border border-gold/30 bg-white/5 px-4 py-3 font-sans text-sm text-ivory placeholder:text-ivory/40 transition-all focus:border-gold focus:bg-white/10 focus:outline-none" placeholder="e.g. Ayesha" />
            </div>
            <div>
              <label htmlFor="rv-comment" className="mb-2 block font-sans text-[0.7rem] uppercase tracking-[0.18em] text-gold-light">Your review</label>
              <textarea id="rv-comment" required minLength={5} maxLength={1000} rows={4} value={comment} onChange={(e) => setComment(e.target.value)} className="w-full resize-none rounded-xl border border-gold/30 bg-white/5 px-4 py-3 font-sans text-sm text-ivory placeholder:text-ivory/40 transition-all focus:border-gold focus:bg-white/10 focus:outline-none" placeholder="Tell others what you love…" />
            </div>
            <button type="submit" disabled={busy} className="btn-gold w-full">
              {busy ? "Submitting…" : "Submit Review"}
            </button>
            {status && (
              <p role="status" className={`font-sans text-sm ${status.type === "ok" ? "text-gold-light" : "text-red-200"}`}>
                {status.text}
              </p>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}

function Stars({ value, small = false }: { value: number; small?: boolean }) {
  return (
    <div className={`flex ${small ? "gap-0.5 text-sm" : "gap-1 text-lg"} text-gold`} aria-label={`${value} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <span key={n} className={n <= value ? "" : "text-gold/25"}>★</span>
      ))}
    </div>
  );
}
