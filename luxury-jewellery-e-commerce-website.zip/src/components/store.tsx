"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type CartItem = {
  key: string;
  productId: number;
  name: string;
  price: number;
  image: string;
  category: string;
  variation: string | null;
  quantity: number;
};

export type WishItem = {
  productId: number;
  name: string;
  price: number;
  image: string;
  category: string;
};

type Store = {
  ready: boolean;
  cart: CartItem[];
  cartCount: number;
  cartSubtotal: number;
  addToCart: (item: Omit<CartItem, "key" | "quantity">, quantity?: number) => void;
  setQuantity: (key: string, quantity: number) => void;
  removeFromCart: (key: string) => void;
  clearCart: () => void;
  wishlist: WishItem[];
  isWishlisted: (productId: number) => boolean;
  toggleWishlist: (item: WishItem) => void;
  removeFromWishlist: (productId: number) => void;
  toast: (message: string) => void;
};

const StoreContext = createContext<Store | null>(null);

const CART_KEY = "ibri-elan-cart-v1";
const WISH_KEY = "ibri-elan-wishlist-v1";

function readJSON<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<WishItem[]>([]);
  const [toastMsg, setToastMsg] = useState<{ id: number; text: string } | null>(null);

  useEffect(() => {
    setCart(readJSON<CartItem[]>(CART_KEY, []));
    setWishlist(readJSON<WishItem[]>(WISH_KEY, []));
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) window.localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart, ready]);

  useEffect(() => {
    if (ready) window.localStorage.setItem(WISH_KEY, JSON.stringify(wishlist));
  }, [wishlist, ready]);

  useEffect(() => {
    if (!toastMsg) return;
    const t = window.setTimeout(() => setToastMsg(null), 2600);
    return () => window.clearTimeout(t);
  }, [toastMsg]);

  const toast = useCallback((text: string) => setToastMsg({ id: Date.now(), text }), []);

  const addToCart = useCallback<Store["addToCart"]>((item, quantity = 1) => {
    const key = `${item.productId}|${item.variation ?? ""}`;
    setCart((prev) => {
      const existing = prev.find((c) => c.key === key);
      if (existing) {
        return prev.map((c) =>
          c.key === key ? { ...c, quantity: Math.min(c.quantity + quantity, 20) } : c,
        );
      }
      return [...prev, { ...item, key, quantity: Math.min(quantity, 20) }];
    });
    toast(`${item.name} added to your cart`);
  }, [toast]);

  const setQuantity = useCallback((key: string, quantity: number) => {
    setCart((prev) =>
      prev
        .map((c) => (c.key === key ? { ...c, quantity: Math.min(Math.max(quantity, 0), 20) } : c))
        .filter((c) => c.quantity > 0),
    );
  }, []);

  const removeFromCart = useCallback((key: string) => {
    setCart((prev) => prev.filter((c) => c.key !== key));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const isWishlisted = useCallback(
    (productId: number) => wishlist.some((w) => w.productId === productId),
    [wishlist],
  );

  const toggleWishlist = useCallback((item: WishItem) => {
    setWishlist((prev) => {
      const exists = prev.some((w) => w.productId === item.productId);
      toast(exists ? `${item.name} removed from wishlist` : `${item.name} saved to wishlist`);
      return exists
        ? prev.filter((w) => w.productId !== item.productId)
        : [...prev, item];
    });
  }, [toast]);

  const removeFromWishlist = useCallback((productId: number) => {
    setWishlist((prev) => prev.filter((w) => w.productId !== productId));
  }, []);

  const value = useMemo<Store>(() => {
    const cartCount = cart.reduce((n, c) => n + c.quantity, 0);
    const cartSubtotal = cart.reduce((n, c) => n + c.quantity * c.price, 0);
    return {
      ready,
      cart,
      cartCount,
      cartSubtotal,
      addToCart,
      setQuantity,
      removeFromCart,
      clearCart,
      wishlist,
      isWishlisted,
      toggleWishlist,
      removeFromWishlist,
      toast,
    };
  }, [
    ready,
    cart,
    wishlist,
    addToCart,
    setQuantity,
    removeFromCart,
    clearCart,
    isWishlisted,
    toggleWishlist,
    removeFromWishlist,
    toast,
  ]);

  return (
    <StoreContext.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-6 z-[100] flex justify-center px-4"
      >
        <div
          key={toastMsg?.id}
          className={`glass rounded-full bg-burgundy-deep/95 px-6 py-3 font-sans text-sm tracking-wide text-ivory shadow-2xl transition-all duration-500 ${
            toastMsg ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
          }`}
        >
          {toastMsg?.text ?? ""}
        </div>
      </div>
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
